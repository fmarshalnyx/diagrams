package com.theice.cfapi.client.example;

import com.theice.cfapi.client.ClientUtils;
import com.theice.cfapi.client.ProgData;
import com.theice.cfapi.data.DateTime;
import com.theice.cfapi.data.MessageReader;
import com.theice.cfapi.event.MessageEvent;
import com.theice.cfapi.event.MessageEventHandler;
import com.theice.cfapi.message.ParserUtils;

import java.util.logging.Logger;

public class MyMessageEventHandler implements MessageEventHandler {
    private final Logger dataLogger = Logger.getLogger("DataLogger");
    private final Logger log = Logger.getLogger(MyMessageEventHandler.class.getName());

    private final ClientSample sample;
    private final ProgData progData;

    public MyMessageEventHandler(ClientSample sample) {
        this.sample = sample;
        this.progData = sample.progData;
    }

    @Override
    public void onMessageEvent(MessageEvent event) {
        if (event.getType().equals(MessageEvent.Types.STATUS) || event.getType().equals(MessageEvent.Types.IMAGE_COMPLETE)) {
            String command = sample.reqMap.get(event.getTag());
            if (!sample.progData.mWatchlist)
                sample.reqMap.remove(event.getTag());

            log.finest(String.format("EventType = %s, Status code = %d (%s) for tag %d (%s)", event.getType().name(), event.getStatusCode(),
                    event.getStatusCodeString(), event.getTag(), command));
        } else if (sample.progData.mConflationIndicator) {
            String tmpStr;
            switch (event.isConflatable()) {
                case 0:
                    tmpStr = "not ";
                    break;
                case 1:
                    tmpStr = "";
                    break;
                default:
                    tmpStr = "not known if ";
            }
            log.info(String.format("This message is %s conflatable.", tmpStr));
        }

        // Only add if each is present
        // PERM/SRC/TICKER is not available for ListEnumeration/ListAvailableTokens/ListAdministrationInfo response
        if (!MessageEvent.Types.STATUS.equals(event.getType())) // STATUS will not contain tokens 3-5
        {
            // Only add if each is present
            if (!progData.mQuiet) { // May be more than one alternate index associated with this message
                for (int i = 0; i < event.getNumberofAlternateIndexes(); i++) {
                    dataLogger.info(String.format("%s(%d)=%s", event.getAlternateIndexTokenName(i), event.getAlternateIndexTokenNumber(i),
                            event.getAlternateIndexValue(i)));
                }
            }
        }

        if (MessageEvent.Types.REFRESH.equals(event.getType()) && !progData.mQuiet) {
            dataLogger.info("REFRESH(24)=1");
        }

        MessageReader reader = event.getReader();
        while (reader.peek() != MessageReader.END_OF_MESSAGE) {
            try {
                reader.next();

                if (reader.isValueNull()) {
                    // field value is null handle, application
                    dataLogger.info(String.format("%s(%d)=%s", reader.getTokenName(), reader.getTokenNumber(), ""));
                    continue;
                }

                switch (reader.getValueType()) {
                    case INT64:
                        if (!progData.mQuiet) {
                            //process the field
                            dataLogger.info(String.format("%s(%d)=%s", reader.getTokenName(), reader.getTokenNumber(), reader.getValueAsInteger()));
                        }
                        break;
                    case STRING:
                        if (!progData.mQuiet) {
                            dataLogger.info(String.format("%s(%d)=%s", reader.getTokenName(), reader.getTokenNumber(), reader.getValueAsString()));
                        }
                        break;
                    case DOUBLE:
                        if (!progData.mQuiet) {
                            dataLogger.info(String.format("%s(%d)=%s", reader.getTokenName(), reader.getTokenNumber(), reader.getValueAsDouble()));
                        }
                        break;
                    case DATETIME:
                        if (!progData.mQuiet) {
                            DateTime datetime = reader.getValueAsDateTime();
                            String dateTimeStr = "null", valueStr = "";
                            if (datetime != null) {
                                dateTimeStr = String.format("%d-%02d-%02d %02d:%02d:%02d.%06d UTC", datetime.date().year(), datetime.date().month(),
                                        datetime.date().day(), datetime.time().hour(), datetime.time().minute(), datetime.time().second(),
                                        (datetime.time().millisecond() * 1000) + datetime.time().microsecond());

                                valueStr = ParserUtils.formatDoubleAsString(reader.getValueAsDouble());
                            }

                            String msgOutStr = String.format("%s(%d)=%s(%s)", reader.getTokenName(), reader.getTokenNumber(), dateTimeStr, valueStr);
                            dataLogger.info(msgOutStr);
                        }
                        break;
                    case UNKNOWN:
                    default:
                        if (!progData.mQuiet) {
                            dataLogger.info(String.format("%s(%d)=%s", reader.getTokenName(), reader.getTokenNumber(), "UNKNOWN value type, cannot decode"));
                        }
                }
            } catch (Exception e) {
                e.printStackTrace();
                log.severe("Error while processing msgevent " + event + " - Exception [ " + ClientUtils.exceptionToString(e) + "].");
            }
        }

        dataLogger.info("<ETX>");
    }
}
