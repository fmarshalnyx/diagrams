package com.theice.cfapi.client.example;

import com.theice.cfapi.client.ProgData;
import com.theice.cfapi.event.UserEvent;
import com.theice.cfapi.event.UserEventHandler;
import com.theice.cfapi.user.UserInfo;

import java.util.logging.Logger;

/*
 * * Simple event handler to print status of login
 */
public class MyUserEventHandler implements UserEventHandler {
    private static final Logger log = Logger.getLogger(MyUserEventHandler.class.getName());

    private static final Logger dataLogger = Logger.getLogger("DataLogger");

    private final ClientSample sample;
    private final ProgData progData;

    public MyUserEventHandler(ClientSample sample) {
        this.sample = sample;
        this.progData = sample.progData;
    }

    static void printAuthStatus(UserInfo user) {
        UserInfo.States userState = user.getState();
        log.info(String.format("Authorization status = %s", userState.toString()));
    }

    @Override
    public void onUserEvent(UserEvent event) {
        UserEvent.Types eventType = event.getType();
        if (eventType.equals(UserEvent.Types.AUTHORIZATION_FAILURE)) {
            log.info(String.format("login failed: return code = %d: %s", event.getRetCode(), event.getRetCodeString()));
        }

        if (progData.mDebug)
            printAuthStatus(event.getSession().getUserInfo());
    }
}