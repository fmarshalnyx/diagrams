package com.theice.cfapi.client.example;

import com.theice.cfapi.event.StatisticsEvent;
import com.theice.cfapi.event.StatisticsEvent.StatsTypes;
import com.theice.cfapi.event.StatisticsEventHandler;

import java.util.logging.Logger;

/**
 * Simple event handler to print API statistics
 */
public class MyStatsEventHandler implements StatisticsEventHandler {
    private Logger dataLogger = Logger.getLogger("DataLogger");
    private Logger logger = Logger.getLogger(MyStatsEventHandler.class.getName());

    public void onStatisticsEvent(StatisticsEvent event) {
        logger.info(String.format(
                "MSGS_IN --> %d; MSGS_OUT --> %d; NET_MSGS_OUT --> %d; DROP --> %d; CSP_DROP --> %d; PCT_FULL=%d/%d; IN_MSGS/SEC(100ms)=%d/%d "
                        + "IN_MSGS/SEC(1sec)=%d/%d; OUT_MSGS/SEC(100ms)=%d/%d OUT_MSGS/SEC(1sec)=%d/%d; NET_OUT_MSGS/SEC(100ms)=%d/%d NET_OUT_MSGS/SEC(1sec)=%d/%d",
                event.getStat(StatsTypes.MSGS_IN), event.getStat(StatsTypes.MSGS_IN), event.getStat(StatsTypes.NET_MSGS_OUT),
                event.getStat(StatsTypes.DROP), event.getStat(StatsTypes.CSP_DROP), event.getStat(StatsTypes.PCT_FULL),
                event.getStat(StatsTypes.PEAK_PCT_FULL), event.getStat(StatsTypes.IN_MSGS_SEC_100MS), event.getStat(StatsTypes.PEAK_IN_MSGS_SEC_100MS),
                event.getStat(StatsTypes.IN_MSGS_SEC), event.getStat(StatsTypes.PEAK_IN_MSGS_SEC), event.getStat(StatsTypes.OUT_MSGS_SEC_100MS),
                event.getStat(StatsTypes.PEAK_OUT_MSGS_SEC_100MS), event.getStat(StatsTypes.OUT_MSGS_SEC), event.getStat(StatsTypes.PEAK_OUT_MSGS_SEC),
                event.getStat(StatsTypes.NET_OUT_MSGS_SEC_100MS), event.getStat(StatsTypes.PEAK_NET_OUT_MSGS_SEC_100MS),
                event.getStat(StatsTypes.NET_OUT_MSGS_SEC), event.getStat(StatsTypes.PEAK_NET_OUT_MSGS_SEC)));
    }
}