package com.theice.cfapi.client.example;

import com.theice.cfapi.client.ClientUtils;
import com.theice.cfapi.client.ProgData;
import com.theice.cfapi.event.MessageEventHandler;
import com.theice.cfapi.event.SessionEvent;
import com.theice.cfapi.event.SessionEventHandler;
import com.theice.cfapi.event.StatisticsEventHandler;
import com.theice.cfapi.net.APIFactory;
import com.theice.cfapi.request.Commands;
import com.theice.cfapi.request.IRequest;
import com.theice.cfapi.request.RequestParameters;
import com.theice.cfapi.session.ConnectionConfig;
import com.theice.cfapi.session.HostConfig;
import com.theice.cfapi.session.Session;
import com.theice.cfapi.session.SessionConfig;
import com.theice.cfapi.user.UserInfo;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Logger;

/*
 ** API test client program - Sample reads the requests from an input file. The input file
 ** have key-value pair instead of ctf tokens & each key value pair is separated by space/tab.
 ** Request Format is :  " COMMAND=value  ENUM_SRC_ID=value  SYMBOL_TICKER=value "
 ** Sample querySnap  :  " COMMAND=QuerySnap  ENUM_SRC_ID=558  SYMBOL_TICKER=IBM "
 */
public class ClientSample {
    private static final String CLIENT_SAMPLE_APP_NAME = "ClientSample";

    private static Logger log;

    private static Logger dataLogger;

    public final ConcurrentHashMap<Long, String> reqMap = new ConcurrentHashMap<>();
    public final ProgData progData;

    private Session session;
    private volatile boolean isSessionEstablished;

    public ClientSample() {
        progData = new ProgData(0l, false, false, false, null, (short) 0, null, (short) 0, null, true, null, -1l, -1l, null, null, 5l, -1l, false, 1, -1l, -1);
    }

    /*
     * * Simple event handler to print status of session
     */
    private class MySessionEventHandler implements SessionEventHandler {
        private final Logger dataLogger = Logger.getLogger("DataLogger");

        @Override
        public void onSessionEvent(SessionEvent sessionEvent) {
            SessionEvent.Types eventType = sessionEvent.getType();
            if (eventType.equals(SessionEvent.Types.CFAPI_SESSION_UNAVAILABLE)) {
                log.info("SESSION_UNAVAILABLE");
                System.out.println("SESSION_UNAVAILABLE");
            } else if (eventType.equals(SessionEvent.Types.CFAPI_SESSION_ESTABLISHED)) {
                log.info("SESSION_ESTABLISHED");
                System.out.println("SESSION_ESTABLISHED");
                isSessionEstablished = true;
            } else if (eventType.equals(SessionEvent.Types.CFAPI_SESSION_RECOVERY)) {
                log.info("SESSION_RECOVERY");
                System.out.println("SESSION_RECOVERY");
            } else if (eventType.equals(SessionEvent.Types.CFAPI_CDD_LOADED)) {
                log.info(String.format("CFAPI_CDD_LOADED; version=%s", sessionEvent.getCddVersion()));
            } else if (eventType.equals(SessionEvent.Types.CFAPI_SESSION_RECOVERY_SOURCES)) {
                int sourceID = sessionEvent.getSourceId();
                log.info(String.format("CFAPI_SESSION_RECOVERY_SOURCES sourceID = %d", sourceID));
            } else if (eventType.equals(SessionEvent.Types.CFAPI_SESSION_AVAILABLE_ALLSOURCES)) {
                int sourceID = sessionEvent.getSourceId();
                log.info(String.format("CFAPI_SESSION_AVAILABLE_ALLSOURCES sourceID = %d", sourceID));
            } else if (eventType.equals(SessionEvent.Types.CFAPI_SESSION_AVAILABLE_SOURCES)) {
                int sourceID = sessionEvent.getSourceId();
                log.info(String.format("CFAPI_SESSION_AVAILABLE_SOURCES sourceID = %d", sourceID));
            } else if (eventType.equals(SessionEvent.Types.CFAPI_SESSION_RECEIVE_QUEUE_ABOVE_THRESHOLD)) {
                log.info(String.format("SESSION_RECEIVE_QUEUE_ABOVE_THRESHOLD (%d)", sessionEvent.getQueueDepth()));
            } else if (eventType == SessionEvent.Types.CFAPI_SESSION_RECEIVE_QUEUE_BELOW_THRESHOLD) {
                log.info(String.format("SESSION_RECEIVE_QUEUE_BELOW_THRESHOLD (%d)", sessionEvent.getQueueDepth()));
            } else if (eventType == SessionEvent.Types.CFAPI_SESSION_SOURCE_ADDED) {
                dataLogger.info(String.format("CFAPI_SESSION_SOURCE_ADDED (%d)", sessionEvent.getSourceId()));
            } else if (eventType == SessionEvent.Types.CFAPI_SESSION_SOURCE_REMOVED) {
                log.info(String.format("CFAPI_SESSION_SOURCE_REMOVED (%d)", sessionEvent.getSourceId()));
            } else {
                log.info("Unknown session state");
                System.out.println("Unknown session state");
            }
        }
    }

    public static void main(String[] args) throws IOException {
        ClientSample sample = new ClientSample();
        boolean areUnknowArgsPassed = false;
        try {
            areUnknowArgsPassed = ClientUtils.buildProgData(args, sample.progData, CLIENT_SAMPLE_APP_NAME);
        } catch (Exception e) {
            e.printStackTrace();
            ClientUtils.printHelp(CLIENT_SAMPLE_APP_NAME);
            return;
        }

        if (args.length < 3 || areUnknowArgsPassed) {
            ClientUtils.printHelp(CLIENT_SAMPLE_APP_NAME);
            return;
        }

        String logDir = System.getProperty("cfapi.logs.dir", "logs");
        String logFileName = System.getProperty("cfapi.logfile", "cfapilog");

        APIFactory.getInstance().initialize(CLIENT_SAMPLE_APP_NAME, "1.0.0", sample.progData.mDebug, logFileName, "", logDir);

        log = Logger.getLogger(ClientSample.class.getName());
        UserInfo primaryUser = APIFactory.getInstance().createUserInfo(sample.progData.mUsername, sample.progData.mPassword, new MyUserEventHandler(sample));

        ClientUtils.setUpDataLogger(sample.progData);
        dataLogger = Logger.getLogger("DataLogger");

        if (sample.progData.mDebug) {
            MyUserEventHandler.printAuthStatus(primaryUser);
        }

        SessionConfig sessionConfig = APIFactory.getInstance().getSessionConfig();
        if (sample.progData.mMultithread) {
            sessionConfig.set(SessionConfig.Parameters.MULTITHREADED_API_CONNECTIONS_BOOL, "true");

            if (sample.progData.mMaxUserThreads != -1) {
                sessionConfig.set(SessionConfig.Parameters.MAX_USER_THREADS_LONG, String.valueOf(sample.progData.mMaxUserThreads));
            }
            if (sample.progData.mMaxCspThreads != -1) {
                sessionConfig.set(SessionConfig.Parameters.MAX_CSP_THREADS_LONG, String.valueOf(sample.progData.mMaxCspThreads));
            }
        } else {
            sessionConfig.set(SessionConfig.Parameters.MULTITHREADED_API_CONNECTIONS_BOOL, "false");
            sessionConfig.set(SessionConfig.Parameters.MAX_USER_THREADS_LONG, String.valueOf(sample.progData.mMaxUserThreads));
            sessionConfig.set(SessionConfig.Parameters.MAX_CSP_THREADS_LONG, String.valueOf(sample.progData.mMaxCspThreads));
        }
        sessionConfig.set(SessionConfig.Parameters.MAX_REQUEST_QUEUE_SIZE_LONG, String.valueOf(sample.progData.mReqQueueSize));

        if (sample.progData.mWatchlist)
            sessionConfig.set(SessionConfig.Parameters.WATCHLIST_BOOL, "true");

        if (sample.progData.mWatchlistSize != -1)
            sessionConfig.set(SessionConfig.Parameters.MAX_WATCHLIST_SIZE_LONG, String.valueOf(sample.progData.mWatchlistSize));

        if (sample.progData.mQueueThreshold != -1)
            sessionConfig.set(SessionConfig.Parameters.QUEUE_DEPTH_THRESHOLD_PERCENT_LONG, String.valueOf(sample.progData.mQueueThreshold));

        ConnectionConfig connectionConfig = APIFactory.getInstance().getConnectionConfig();
        ClientUtils.buildConnectionConfig(sample.progData, connectionConfig);

        if (!sample.progData.mPrimaryConn.isEmpty()) {
            for (String hostConfigStr : sample.progData.mPrimaryConn) {
                HostConfig hostConfig = ClientUtils.buildHostConfig(hostConfigStr, false);
                connectionConfig.setHostconfig(hostConfig);
            }
        } else // Primary conn not specified
        {
            log.severe(" Error - Primary connection not specified");
            ClientUtils.printHelp(CLIENT_SAMPLE_APP_NAME);
            return;
        }

        if (!sample.progData.mBackupConn.isEmpty()) // backup server
        {
            if (sample.progData.mBackupConn.size() != sample.progData.mPrimaryConn.size()) {
                log.severe("Error - The no of backup connections should be same as the primary connections");
                ClientUtils.printHelp(CLIENT_SAMPLE_APP_NAME);
                return;
            }

            for (String hostConfigStr : sample.progData.mBackupConn) {
                HostConfig hostConfig = ClientUtils.buildHostConfig(hostConfigStr, true);
                connectionConfig.setHostconfig(hostConfig);
            }
        }

        // register to get called when messages received
        MessageEventHandler responseEH = new MyMessageEventHandler(sample);

        sample.session = APIFactory.getInstance().createSession(primaryUser, sample.new MySessionEventHandler(), sessionConfig, connectionConfig, responseEH);

        StatisticsEventHandler statsEH = new MyStatsEventHandler();
        if (sample.progData.mStatsInterval > 0)
            sample.session.registerStatisticsEventHandler(statsEH, (int) sample.progData.mStatsInterval);

        ClientUtils.logProgramData(sample.progData);

        URL configFileUrl = ClassLoader.getSystemResource(sample.progData.mFileName);
        if (configFileUrl == null) {
            log.info("Client input file " + sample.progData.mFileName + " is not available.");
            System.exit(1);
        }

        boolean ret = sample.session.start();
        if (!ret) {
            log.info("session could not be established");
            System.exit(1);
        }
        log.info("session Started");

        while (true) {
            if (sample.isSessionEstablished) {
                sample.sendIt();
                break;
            } else {
                try {
                    Thread.sleep(100L);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
        log.info("Ending client sample.");
        try {
            Thread.sleep(5000L);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        // // log.info("ctrl-c pressed to quit.");
        // log.info("Stopping API session.");
        // sample.session.stop();
    }

    void sendIt() {
        try {
            URL configFileUrl = ClassLoader.getSystemResource(progData.mFileName);
            BufferedReader reader = new BufferedReader(new InputStreamReader(configFileUrl.openStream()));
            String line;
            String origLine;
            while ((line = reader.readLine()) != null) {
                line = line.trim();
                origLine = line;
                if (!line.isEmpty() && line.charAt(0) != '#') {
                    log.finest(line);
                    long reqHandle = 0;
                    boolean queueFull = false;
                    // Parse message, convert to API request
                    IRequest request = session.createNewRequest();
                    boolean badMsg = parseLineAndPopulateReq(line, request);

                    // API send request -- if ok
                    if (!badMsg) {
                        reqHandle = request.generateTag(); // pre-generate unique tag

                        reqMap.put(reqHandle, origLine);
                        reqHandle = session.send(request);
                        if (reqHandle == 0)
                            queueFull = true;
                    }

                    if (!progData.mQuiet) {
                        if (badMsg)
                            log.info(String.format("Invalid message not sent:[%s]", origLine));
                        else if (queueFull)
                            log.info(String.format("Error: send queue is full, cannot send %s", origLine));
                        else
                            log.finest(String.format("Send:[%s]: tag =[%d]", origLine, reqHandle));
                    }
                }
            }

            log.finest("Ending, sent all input.");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * @param line
     * @param request
     * @return
     */
    public boolean parseLineAndPopulateReq(String line, IRequest request) {
        String cmd;
        String val;
        boolean badMsg = false;
        boolean quotedVal;
        int start_of_val = 0;
        int cmdStart = 0;
        while (line != null && !line.trim().isEmpty()) {

            int eq = line.indexOf("=");
            if (eq == -1) {
                badMsg = true;
                log.info(String.format("Missing '=': %s", line));
                break;
            }

            cmd = line.substring(cmdStart, eq - cmdStart);
            val = line.substring(eq + 1);

            if (val.charAt(0) == '"') {
                quotedVal = true;
                start_of_val = 1;
            } else {
                quotedVal = false;
                start_of_val = 0;
            }

            int end_of_val = -1;
            if (quotedVal) {
                end_of_val = val.indexOf('"', start_of_val);
            } else {
                end_of_val = val.indexOf(' ');
                if (end_of_val == -1) {
                    end_of_val = val.indexOf('\t');
                }
            }

            if (end_of_val == -1) {
                if (quotedVal) {
                    badMsg = true;
                    log.info(String.format("Missing end-quote: %s", val));
                    break;
                } else {
                    line = null;
                }
            } else {
                val = val.substring(start_of_val, end_of_val - start_of_val + 1);
                line = line.substring(eq + 1 + end_of_val + 1);
            }

            String req = null;
            RequestParameters reqParameter = RequestParameters.getReqToken(cmd.trim());
            int ctfid = 0;
            if (cmd != null) {
                try {
                    ctfid = Integer.parseInt(cmd.trim());
                } catch (Exception e) {
                }
            }

            val = val.trim();

            if (RequestParameters.COMMAND.equals(reqParameter)) {
                req = val;
                req = req.toUpperCase();
                Commands command = Commands.getCommandByName(req);
                if (command != null) {
                    request.setCommand(command);
                } else {
                    log.info(String.format("Invalid command: %s", val));
                    badMsg = true;
                }
            } else if (reqParameter != null) {
                request.add(reqParameter.getTokenNum(), val);
            } else if (ctfid > 0) {
                request.add(ctfid, val); // ignore
            } else {
                badMsg = true;
                log.info(String.format("Invalid token in the request: %s", cmd));
            }

            if (badMsg)
                break;
        }
        return badMsg;
    }

}
