package com.theice.cfapi.user;

public interface UserInfoProcessor
{
	UserInfo.States getUserState();
}
