package com.theice.cfapi.user;

public interface UserInfo
{
	/**
	 * State of this user.
	 */
	public enum States
	{
		/**
		 * Not authenticated to any backend CSPs
		 */
		NOT_AUTHENTICATED(0),
		/**
		 * Authenticated to all backend CSPs
		 */
		AUTHENTICATED(1),
		/**
		 * Authenticated to at least one backend CSP, but not authenticated to at least one CSP
		 */
		PARTIALLY_AUTHENTICATED(2);

		int value;

		private States(int value)
		{
			this.value = value;
		}

		public int getValue()
		{
			return value;
		}
	};

	States getState();

	UserInfoProcessor getUsrInfoEventProcessor();
}
