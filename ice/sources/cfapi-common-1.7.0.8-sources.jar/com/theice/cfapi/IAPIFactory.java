package com.theice.cfapi;

import com.theice.cfapi.event.MessageEventHandler;
import com.theice.cfapi.event.SessionEventHandler;
import com.theice.cfapi.event.UserEventHandler;
import com.theice.cfapi.session.ConnectionConfig;
import com.theice.cfapi.session.Session;
import com.theice.cfapi.session.SessionConfig;
import com.theice.cfapi.user.UserInfo;

public interface IAPIFactory
{
	/**
	 * Initializes the API for real use, must be called before any request Parameter "usage" is used for only internal purpose;
	 */
	int initialize(String appName, String appVersion, boolean debug, String logFileName, String usage);

	/**
	 * Initializes the API for real use, must be called before any request Parameter "usage" is used for only internal purpose;
	 */
	 int initialize(String appName, String appVersion, boolean debug, String logFileName, String usage, String logDir);

	/**
	 * Create a new UserInfo object.
	 */
	 UserInfo createUserInfo(String username, String password, UserEventHandler userHandler);

	/**
	 * Create a new session.
	 */
	@Deprecated
	Session createSession(UserInfo primaryUser, SessionEventHandler sessionHandler);

	/**
	 * Destroy the session after the usage is done with it.
	 */
	void destroySession(Session session);

    Session createSession(UserInfo primaryUser, SessionEventHandler mySessionEventHandler, SessionConfig sessionConfig, ConnectionConfig connectionConfig, MessageEventHandler responseEH);
}
