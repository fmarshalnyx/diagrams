package com.theice.cfapi.client;

import com.theice.cfapi.request.IRequest;

import java.util.logging.Logger;

public class Util {
    private static final Logger LOGGER = Logger.getLogger(Util.class.getName());

    public static final String WIN = "win";
    public static final String NIX = "nix";
    public static final String NUX = "nux";
    public static final String AIX = "aix";
    public static final String MAC = "mac";
    public static final String SUNOS = "sunos";
    public static final String SYS_PROP_OS_NAME = "os.name";
    private static volatile OS os = null;

    public static OS getOS() {
        if (os == null) {
            String operSys = System.getProperty(SYS_PROP_OS_NAME).toLowerCase();
            if (operSys.contains(WIN)) {
                os = OS.WINDOWS;
            } else if (operSys.contains(NIX) || operSys.contains(NUX)
                    || operSys.contains(AIX)) {
                os = OS.LINUX;
            } else if (operSys.contains(MAC)) {
                os = OS.MAC;
            } else if (operSys.contains(SUNOS)) {
                os = OS.SOLARIS;
            }
        }
        return os;
    }

    public static void main(String[] args) {
        System.out.println(getOS());
        add(5052, 1);
        add(4, 122);
    }

    public enum OS {
        WINDOWS, LINUX, MAC, SOLARIS
    }



    public static void add(int parameter, int value)
    {
        boolean isTagSetInString = false;
        int srcid, origTag;
        StringBuilder params = new StringBuilder();
        switch (parameter)
        {
            case 5022: // command
            case 5026: // tag
                LOGGER.warning(String.format("Invalid parameter (%d) passed to Request::add", parameter));
                break; // discard
            case 5052:	//original tag -- save for watchlist unsubscribe
                LOGGER.warning("added 5052/QUERY_REF_TAG as an int; however, tag from API is int64_t; value may not be interpreted correctly");
            case 4:	//srcid -- save for routing
                if (parameter == 4)
                    srcid = value;
                if (parameter == 5052)
                    origTag = value;
            default: // write into CTF format....
                if (isTagSetInString)
                    params.append(String.format("|%d=%d|", parameter, value));
                else
                    params.append(String.format("%d=%d|", parameter, value));
        }
    }


}