package com.theice.cfapi.client;

import java.io.BufferedWriter;
import java.io.DataOutputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.logging.Level;
import java.util.logging.Logger;

public class SimpleFileWriter
{
	private static final Logger LOGGER = Logger.getLogger(SimpleFileWriter.class.getName());

	protected final String lineSeperator = System.getProperty("line.separator");
	protected String filename;
	private BufferedWriter buffFW;

	public SimpleFileWriter()
	{
	}

	public SimpleFileWriter(String filename)
	{
		this.filename = filename;
		this.buffFW = createFileWriter();
	}

	public synchronized void writeLine(String line)
	{
		try
		{
			buffFW.write(line + lineSeperator);
		}
		catch (IOException e)
		{
			LOGGER.log(Level.SEVERE, "Exception while persisting data to " + filename, e);
		}
	}

	public synchronized void writeLine(String line, boolean addEOL)
	{
		if (addEOL)
		{
			writeLine(line);
		}
		else
		{
			try
			{
				buffFW.write(line);
			}
			catch (IOException e)
			{
				LOGGER.log(Level.SEVERE, "Exception while persisting data to " + filename, e);
			}
		}
	}

	public synchronized void flush()
	{
		if (null != buffFW)
		{
			try
			{
				buffFW.flush();
			}
			catch (IOException e)
			{
				LOGGER.log(Level.SEVERE, "Exception while flushing data to " + filename, e);
			}
		}
	}

	public synchronized void close()
	{
		if (null != buffFW)
		{
			try
			{
				buffFW.flush();
				buffFW.close();
			}
			catch (IOException e)
			{
				LOGGER.log(Level.SEVERE, "Exception while closing file " + filename, e);
			}
		}
	}

	private BufferedWriter createFileWriter()
	{
		BufferedWriter buffFW = null;
		try
		{
			FileOutputStream fileOutputStream = new FileOutputStream(filename);
			DataOutputStream out = new DataOutputStream(fileOutputStream);
			buffFW = new BufferedWriter(new OutputStreamWriter(out));
		}
		catch (FileNotFoundException e)
		{
			throw new RuntimeException("Error reading in file " + filename, e);
		}
		return buffFW;
	}
}
