package com.theice.cfapi.client;

import java.util.LinkedHashSet;
import java.util.Set;

public class ProgData
{
	// Receive this # of Bps; 0 => unlimited
	public long mDataRate;
	public boolean mQuiet;
	public boolean mDebug;
	public boolean mMultithread;
	public String mRemoteHost;
	public short mRemotePort;
	public String mRemoteHost2;
	public short mRemotePort2;
	public String mFileName;
	public boolean mCompressedData = true;
	public String outputToFile;
	public long mMaxUserThreads = 1;
	public long mMaxCspThreads = 1;
	public String mUsername;
	public String mPassword;
	public long mReadTimeout = 5;
	public long mStatsInterval;
	public boolean mConflationIndicator;
	public int queueSizeInMegaBytes;
	public long mReqQueueSize = -1;
	public long	mSessionRestartRequested;
	public int mConflInterval = 1000;
	public int mConflType = -1;
	public int mJitThreshold = -1;
	public boolean mWatchlist = false;
	public long mWatchlistSize = -1;
	public String mNatFile;
	public int mQueueThreshold = -1;
	public final Set<String> mPrimaryConn = new LinkedHashSet<>();
	public final Set<String> mBackupConn = new LinkedHashSet<>();

	public ProgData(long mDataRate, boolean mQuiet, boolean mDebug, boolean mMultithread, String mRemoteHost,
					short mRemotePort, String mRemoteHost2, short mRemotePort2, String mFileName, boolean mCompressedData,
					String outputToFile, long mMaxUserThreads, long mMaxCspThreads, String mUsername, String mPassword,
					long mReadTimeout, long mStatsInterval, boolean mConflationIndicator, int queueSizeInMegaBytes,
					long mReqQueueSize, int mQueueThreshold)
	{
		this.mDataRate = mDataRate;
		this.mQuiet = mQuiet;
		this.mDebug = mDebug;
		this.mMultithread = mMultithread;
		this.mRemoteHost = mRemoteHost;
		this.mRemotePort = mRemotePort;
		this.mRemoteHost2 = mRemoteHost2;
		this.mRemotePort2 = mRemotePort2;
		this.mFileName = mFileName;
		this.mCompressedData = mCompressedData;
		this.outputToFile = outputToFile;
		this.mMaxUserThreads = mMaxUserThreads;
		this.mMaxCspThreads = mMaxCspThreads;
		this.mUsername = mUsername;
		this.mPassword = mPassword;
		this.mReadTimeout = mReadTimeout;
		this.mStatsInterval = mStatsInterval;
		this.mConflationIndicator = mConflationIndicator;
		this.queueSizeInMegaBytes = queueSizeInMegaBytes;
		this.mReqQueueSize = mReqQueueSize;
		this.mQueueThreshold = mQueueThreshold;
	}

	public long getmDataRate()
	{
		return mDataRate;
	}

	public void setmDataRate(long mDataRate)
	{
		this.mDataRate = mDataRate;
	}

	public boolean ismQuiet()
	{
		return mQuiet;
	}

	public void setmQuiet(boolean mQuiet)
	{
		this.mQuiet = mQuiet;
	}

	public boolean ismDebug()
	{
		return mDebug;
	}

	public void setmDebug(boolean mDebug)
	{
		this.mDebug = mDebug;
	}

	public boolean ismMultithread()
	{
		return mMultithread;
	}

	public void setmMultithread(boolean mMultithread)
	{
		this.mMultithread = mMultithread;
	}

	public String getmRemoteHost()
	{
		return mRemoteHost;
	}

	public void setmRemoteHost(String mRemoteHost)
	{
		this.mRemoteHost = mRemoteHost;
	}

	public short getmRemotePort()
	{
		return mRemotePort;
	}

	public void setmRemotePort(short mRemotePort)
	{
		this.mRemotePort = mRemotePort;
	}

	public String getmRemoteHost2()
	{
		return mRemoteHost2;
	}

	public void setmRemoteHost2(String mRemoteHost2)
	{
		this.mRemoteHost2 = mRemoteHost2;
	}

	public short getmRemotePort2()
	{
		return mRemotePort2;
	}

	public void setmRemotePort2(short mRemotePort2)
	{
		this.mRemotePort2 = mRemotePort2;
	}

	public String getmFileName()
	{
		return mFileName;
	}

	public void setmFileName(String mFileName)
	{
		this.mFileName = mFileName;
	}

	public boolean ismCompressedData()
	{
		return mCompressedData;
	}

	public void setmCompressedData(boolean mCompressedData)
	{
		this.mCompressedData = mCompressedData;
	}

	public String getOutputToFile()
	{
		return outputToFile;
	}

	public void setOutputToFile(String outputToFile)
	{
		this.outputToFile = outputToFile;
	}

	public long getmMaxUserThreads()
	{
		return mMaxUserThreads;
	}

	public void setmMaxUserThreads(long mMaxUserThreads)
	{
		this.mMaxUserThreads = mMaxUserThreads;
	}

	public long getmMaxCspThreads()
	{
		return mMaxCspThreads;
	}

	public void setmMaxCspThreads(long mMaxCspThreads)
	{
		this.mMaxCspThreads = mMaxCspThreads;
	}

	public String getmUsername()
	{
		return mUsername;
	}

	public void setmUsername(String mUsername)
	{
		this.mUsername = mUsername;
	}

	public String getmPassword()
	{
		return mPassword;
	}

	public void setmPassword(String mPassword)
	{
		this.mPassword = mPassword;
	}

	public long getmReadTimeout()
	{
		return mReadTimeout;
	}

	public void setmReadTimeout(long mReadTimeout)
	{
		this.mReadTimeout = mReadTimeout;
	}

	public long getmStatsInterval()
	{
		return mStatsInterval;
	}

	public void setmStatsInterval(long mStatsInterval)
	{
		this.mStatsInterval = mStatsInterval;
	}

	public boolean ismConflationIndicator()
	{
		return mConflationIndicator;
	}

	public void setmConflationIndicator(boolean mConflationIndicator)
	{
		this.mConflationIndicator = mConflationIndicator;
	}

	public Set<String> getmPrimaryConn()
	{
		return mPrimaryConn;
	}

	public Set<String> getmBackupConn()
	{
		return mBackupConn;
	}

}
