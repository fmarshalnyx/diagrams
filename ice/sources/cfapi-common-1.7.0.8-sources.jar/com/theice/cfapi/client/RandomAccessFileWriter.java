package com.theice.cfapi.client;

import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.logging.Logger;

public class RandomAccessFileWriter extends SimpleFileWriter
{
	private static final Logger LOGGER = Logger.getLogger(RandomAccessFileWriter.class.getName());

	private final String lineSeperator = System.getProperty("line.separator");
	private RandomAccessFile randomAccessFile;
	// private FileChannel rwChannel;
	// private MappedByteBuffer rwBB;

	public RandomAccessFileWriter(String filename)
	{
		this.filename = filename;
		try
		{
			this.randomAccessFile = new RandomAccessFile(filename, "rw");
			// this.rwChannel = this.randomAccessFile.getChannel();
			// rwBB = this.rwChannel.map(MapMode.READ_WRITE, 0, 184000000);
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
	}

	public void writeLine(String line)
	{
		try
		{
			// rwBB.put((line + lineSeperator).getBytes());
			randomAccessFile.write((line + lineSeperator).getBytes());
		}
		catch (IOException e)
		{
			e.printStackTrace();
			LOGGER.severe("Exception while persisting data to " + filename);
		}
	}

	public void writeLine(String line, boolean addEOL)
	{
		if (addEOL)
		{
			writeLine(line);
		}
		else
		{
			try
			{
				randomAccessFile.write((line).getBytes());
			}
			catch (IOException e)
			{
				e.printStackTrace();
				LOGGER.severe("Exception while persisting data to " + filename);
			}
		}
	}

	public void flush()
	{
	}

	public void close()
	{
		if (null != randomAccessFile)
		{
			try
			{
				randomAccessFile.close();
			}
			catch (IOException e)
			{
				e.printStackTrace();
				LOGGER.severe("Exception while closing file " + filename);
			}
		}
	}

	public static void main(String[] args)
	{

	}
}
