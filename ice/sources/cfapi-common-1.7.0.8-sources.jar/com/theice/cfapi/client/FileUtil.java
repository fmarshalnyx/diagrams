package com.theice.cfapi.client;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileFilter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TreeMap;
import java.util.logging.Logger;

public class FileUtil
{
	private static final Logger LOGGER = Logger.getLogger(FileUtil.class.getName());

	public static List<String> readFile(String fileName)
	{
		FileReader fr = null;
		BufferedReader br = null;
		List<String> fileContent = new ArrayList<String>();
		// if (!new File(fileName).exists()) return fileContent;
		try
		{
			String line = null;
			fr = new FileReader(fileName);
			br = new BufferedReader(fr);

			while ((line = br.readLine()) != null && line.length() > 0)
			{
				fileContent.add(line);
			}
		}
		catch (Exception e)
		{
			LOGGER.severe(ClientUtils.exceptionToString(e));
		}
		finally
		{
			closeReader(fr);
			closeReader(br);
		}
		return fileContent;
	}

	public static void closeReader(Reader rr)
	{
		try
		{
			if (rr != null)
			{
				rr.close();
			}
		}
		catch (Exception e2)
		{
			LOGGER.severe(ClientUtils.exceptionToString(e2));
		}
	}

	public static synchronized void writeToFile(String fileNameWithPath, String data, boolean append) throws Throwable
	{
		FileWriter fw = null;
		try
		{
			fw = new FileWriter(fileNameWithPath, append);
			fw.write(data);
			if (append)
			{
				fw.write("\n");
			}
			fw.flush();
		}
		finally
		{
			closeWriter(fw);
		}
	}

	public static void closeWriter(Writer writer)
	{
		try
		{
			if (writer != null)
			{
				writer.close();
			}
		}
		catch (Exception e2)
		{
			LOGGER.severe(ClientUtils.exceptionToString(e2));
		}
	}

	/**
	 * @param dir
	 */
	public static boolean makeDirs(String dirPath)
	{
		boolean result = false;
		try
		{
			File dir = new File(dirPath);
			result = dir.mkdirs();
			if (result)
			{
				LOGGER.info("Sucessfully created " + dirPath + " dir.");
			}
			else
			{
				LOGGER.info("Unable to create " + dirPath + " dir.");
			}
		}
		catch (Exception exe)
		{
			LOGGER.severe("Exception while creating " + dirPath + " dir, [ " + ClientUtils.exceptionToString(exe) + "].");
		}

		return result;
	}

	public static String buildFilePath(String dir, String... fileAttrs)
	{
		StringBuilder fullPath = new StringBuilder(dir);
		fullPath.append(File.separator);

		if (fileAttrs != null)
		{
			for (String attr : fileAttrs)
			{
				if (attr != null && !"".equals(attr) && !"null".equals(attr))
				{
					fullPath.append(attr).append(File.separator);
				}
			}
		}

		return fullPath.toString().substring(0, fullPath.toString().length() - 1);
	}

	public static File buildFile(String dir, String... fileAttrs)
	{
		String fullPath = buildFilePath(dir, fileAttrs);
		return new File(fullPath);
	}

	public static File buildAndCreateFileDirPath(String baseDir, String... dirPathAttrs)
	{
		String dirPath = buildFilePath(baseDir, dirPathAttrs);

		File fileDir = new File(dirPath);
		if (!fileDir.exists())
		{
			makeDirs(dirPath);
		}
		return fileDir;
	}

	public static File buildAndCreateFile(File dirFile, String... fileAttr)
	{
		File fileToCreate = buildFile(dirFile.getPath(), fileAttr);
		if (!fileToCreate.exists())
		{
			try
			{
				fileToCreate.createNewFile();
			}
			catch (IOException e)
			{
				e.printStackTrace();
			}
		}
		else
		{
			LOGGER.info("File " + fileToCreate.getPath() + " already exists.");
		}
		return fileToCreate;
	}

	public static File createAndConstructRollingFile(String dirPath, final String fileName, final String suffix)
	{
		File fileDir = buildAndCreateFileDirPath(null, dirPath);
		int fnameIdxToUse = 0;

		if (fileDir.exists())
		{
			File[] maketDataFiles = fileDir.listFiles(new FileFilter()
			{
				@Override
				public boolean accept(File pathname)
				{
					String fname = pathname.getName();
					if (fname.startsWith(fileName + suffix))
					{
						return true;
					}
					else
					{
						return false;
					}
				}
			});

			renameRollingFiles(maketDataFiles);
		}

		File file = new File(fileDir, fileName + suffix);

		return file;
	}

	private static void renameRollingFiles(File[] maketDataFiles)
	{
		Map<Integer, File> rollingFileIndxs = new TreeMap<Integer, File>(new Comparator<Integer>()
		{
			@Override
			public int compare(Integer o1, Integer o2)
			{
				if (o1 > o2)
				{
					return -1;
				}
				if (o1 < o2)
				{
					return 1;
				}
				else
				{
					return 0;
				}
			}
		});

		for (File file : maketDataFiles)
		{
			String filename = file.getName();
			String[] fnameElems = filename.split(".");
			int fnameIdx = 0;
			try
			{
				fnameIdx = Integer.parseInt(fnameElems[fnameElems.length - 1]);
				rollingFileIndxs.put(fnameIdx, file);
			}
			catch (Exception e)
			{
			}
		}

		Iterator<Entry<Integer, File>> ite = rollingFileIndxs.entrySet().iterator();
		Entry<Integer, File> entryToProcess = null;
		if (ite.hasNext())
		{
			entryToProcess = ite.next();
		}

		Entry<Integer, File> prevEntryToProcess = null;
		while (entryToProcess != null)
		{
			Entry<Integer, File> nextEntry = null;
			if (ite.hasNext())
			{
				nextEntry = ite.next();
			}

			if (entryToProcess.getKey() == nextEntry.getKey() + 1)
			{
				// entryToProcess.getValue().renameTo()
			}

			prevEntryToProcess = entryToProcess;
			entryToProcess = nextEntry;
		}

	}

	/**
	 * Recursively touch file and directories.
	 * 
	 * @param File
	 *            (file or directory) for touching.
	 */
	public static void touch(File file, long time)
	{
		if (file.isDirectory())
		{
			File[] files = file.listFiles();
			for (int i = 0; i < files.length; i++)
			{
				touch(files[i], time);
			}
		}
		else
		{
			file.setLastModified(time);
		}
	}

}
