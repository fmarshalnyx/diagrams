package com.theice.cfapi.client;

import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.LockSupport;

/**
 *
 */
public class ThreadUtil {

    //	private static final int QUEUE_POLL_TIMEOUT_IN_NANOS = 100;
    private static final TimeUnit QUEUE_POLL_TIMEOUT_TIME_UNIT = TimeUnit.NANOSECONDS;
    //
//	// poll and wait for 100 nanos (in practice, due to the JVM and OS, it could
//	// wait up to 10 micros in Solaris)
    private static final LinkedBlockingQueue<Object> delayQueue = new LinkedBlockingQueue<>();

    public static void sleep(long millis) {
        try {
            Thread.sleep(millis);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    public static void sleepNanoTime(long sleepTimeInNanos) {
        LockSupport.parkNanos(sleepTimeInNanos);
    }

    public static void sleepNanoTimeUsingQ(long sleepTimeInNanos) {
        try {
            delayQueue.poll(sleepTimeInNanos, QUEUE_POLL_TIMEOUT_TIME_UNIT);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    public static void sleepInMicros(long sleepInMicros) {
        sleepNanoTime(sleepInMicros*1000);
    }

}
