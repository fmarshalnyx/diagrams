package com.theice.cfapi.client;

import com.theice.cfapi.log.formatter.DataLoggerFormater;
import com.theice.cfapi.session.ConnectionConfig;
import com.theice.cfapi.session.HostConfig;
import com.theice.cfapi.session.HostConfig.Parameters;

import java.io.*;
import java.net.URL;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.logging.*;

public class ClientUtils
{

	private static final Logger LOGGER = Logger.getLogger(ClientUtils.class.getName());

	public static void parseArgumenets(String[] args, Map<String, String> argsMap, List<String> appArgs)
	{

		for (int i = 0; i < args.length; i++)
		{
			switch (args[i].charAt(0))
			{
			case '-':
				if (args[i].equals("-h") || args[i].equals("-q") || args[i].equals("-D") || args[i].equals("-M") || args[i].equals("-z") || args[i].equals("-c")
						|| args[i].equals("-R") || args[i].equals("-t"))
				{
					argsMap.put(args[i], "");
					break;
				}
				else if (args[i].length() < 2)
				{
					throw new IllegalArgumentException("Not a valid argument: " + args[i]);
				}
				else
				{
					if (args[i].equals("-P") || args[i].equals("-S"))
					{
						String ip = args[++i];
						String port = args[++i];
						argsMap.put(args[i], String.format("%s:%s", ip, port));
					}
					else
					{
						argsMap.put(args[i], args[i + 1]);
						i++;
					}
					break;
				}

			default:
				// arg
				appArgs.add(args[i]);
				break;
			}
		}

	}

	public static void printHelp(String appName)
	{
		System.out.println(String.format("Usage: %s [-h] [-q] [-D] [-o output file] -u userid -p password [-M] [-U max_user_threads] [-C max_csp_threads] [-z] [-c] "
				+ "[-r read timeout] [-s interval] [-c] [-Q queue size] [-I input-_req_q_size] [-a conflation_interval] [-n NAT_file] [-t conflation_type] [-j JIT_threshold] [-T queue_threshold] -P primary_host_ip_address primary_port [-B backup_host_ip_address backup_port] input_command_file",
				appName));

		System.out.println("-h:             Prints this help message");
		System.out.println("-q:             Quiet mode - don't print data");
		System.out.println("-D:             Debug mode - print API debug messages to console");
		System.out.println("-o:             Output file - write data here instead of console");
		System.out.println("-u:             userid for CSP");
		System.out.println("-p:             password for CSP");
		System.out.println("-M:             Use Multithreading mode in API [One thread per TCP connection to CSP for better performnce]");
		System.out.println("-U:             Max user-side threads API may create when in Multithreading mode - [with -M option]");
		System.out.println("-C:             Max CSP-side threads API may create when in Multithreading mode - [with -M option]");
		System.out.println("-z:             Turn off compression between API and CSP");
		System.out.println("-r:             Read timeout in seconds");
		System.out.println("-s:             Get API statistics; specify interval in seconds");
		System.out.println("-c:             Request conflation indicator");
		System.out.println("-Q:             Queue size in megabytes		[Default 1 MB]");
		System.out.println("-I:             input request queue size	[Default 100000(requests)]");
		System.out.println("-a:             Conflation interval in milliseconds. Default is 1000 (ms)");
		System.out.println("-n:             NAT IP address mapping file (each line should contain <CSP IP addr>,<local IP addr>)");
		System.out.println("-t:             Conflation type. 1=Trade Safe(default); 2=Intervalized; 3=Just-In-Time (JIT); 4=Just-In-Time(JIT) Intervalized");
		System.out.println("-j:             JIT Conflation threshold. Buffer percent full to trigger conflation. 1-75 Default is 25. Only valid with -t3 or -t4");
		System.out.println("-w:             Use watchlist. [Default is false]");
		System.out.println("-W:             Max watchlist size. [Default 10000000(requests)]");
		System.out.println("-T:             Queue threshold. Buffer percent full to trigger CFAPI_SESSION_RECEIVE_QUEUE_ABOVE_THRESHOLD and CFAPI_SESSION_RECEIVE_QUEUE_BELOW_THRESHOLD SessionEvents. 1-101 Default is 70%");

		System.out.println("-P:				Primary connection  with <IP addr><Port no>");
		System.out.println("-B: 			Backup connection  with <IP addr><Port no>");

		System.out.println("input_command_file:  file containing CTF commands");
	}

	public static void printHelp()
	{
		printHelp("sample");
	}

	public static void logProgramData(ProgData progData)
	{
		System.out.println("Quiet mode - don't print data (-q): " + progData.mQuiet);
		System.out.println("Debug mode - print API debug messages to console (-D): " + progData.mDebug);
		System.out.println("Output file - write data here instead of console (-o): " + progData.outputToFile);
		System.out.println("userid for CSP (-u): " + progData.mUsername);
		System.out.println("password for CSP (-p): " + progData.mPassword);
		System.out.println("Use Multithreading mode in API (-M): " + progData.mMultithread);
		System.out.println("Max user-side threads to create (-U): " + progData.getmMaxUserThreads());
		System.out.println("Max CSP-side threads to create (-C): " + progData.getmMaxCspThreads());
		System.out.println("Use compression between API and CSP (-z): " + progData.mCompressedData);
		System.out.println("Read timeout in seconds (-r): " + progData.mReadTimeout);
		System.out.println("Get API statistics; specify interval in seconds (-s): " + progData.mStatsInterval);
		System.out.println("Request conflation indicator (-c): " + progData.mConflationIndicator);
		System.out.println("Queue size in megabytes (-Q): " + progData.queueSizeInMegaBytes);
		System.out.println("Input request queue size (-I)	[Default 100000(requests)]" + progData.mReqQueueSize);
		System.out.println("Conflation interval in milliseconds(-a) [Default is 1000 (ms)]: " + progData.mConflInterval);		
		System.out.println("Conflation type (-t) [1=Trade Safe(default), 2=Intervalized, 3=Just-In-Time (JIT), 4=Just-In-Time(JIT) Intervalized]: " + progData.mConflType);
		System.out.println("JIT Conflation threshold (-j). Buffer percent full to trigger conflation. 1-75 (Default is 25, only valid with -t3 or -t4): " + progData.mJitThreshold);
		System.out.println("Queue threshold (-T) Buffer percent full to trigger CFAPI_SESSION_RECEIVE_QUEUE_ABOVE_THRESHOLD and CFAPI_SESSION_RECEIVE_QUEUE_BELOW_THRESHOLD SessionEvents. 1-101 (Default is 70): " + progData.mQueueThreshold);
		System.out.println("Use watchlist [Default is false] " + progData.mWatchlist);
		System.out.println("Max watchlist size [Default 10000000(requests)]: " + progData.mWatchlistSize);
		System.out.println("NAT IP address mapping file (each line should contain <CSP IP addr>,<local IP addr>) (-n): " + progData.mNatFile);
		System.out.println("Primary connection  with <IP addr><Port no> (-P): " + progData.mPrimaryConn);
		System.out.println("Backup connection  with <IP addr><Port no> (-B): " + progData.mBackupConn);
		System.out.println("Input file containing CTF commands: " + progData.getmFileName());
	}

	public static boolean buildProgData(String[] args, ProgData progData, String name)
	{
		Set<Integer> primaryPorts = new HashSet<>();
		Set<Integer> backupPorts = new HashSet<>();
		boolean unknowArgsPassed = false;
		for (int i = 0; i < args.length - 1; i++)
		{
			String arg = args[i];
			if (arg.equals("-q"))
			{
				progData.mQuiet = true;
			}
			else if (arg.equals("-D"))
			{
				progData.mDebug = true;
			}
			else if (arg.equals("-o"))
			{
				progData.outputToFile = args[++i];
			}
			else if (arg.equals("-z"))
			{
				progData.mCompressedData = false;
			}
			else if (arg.equals("-M"))
			{
				progData.mMultithread = true;
			}
			else if (arg.equals("-u"))
			{
				String username = args[++i];
				if (username != null)
				{
					progData.mUsername = username;
				}
			}
			else if (arg.equals("-p"))
			{
				String password = args[++i];
				if (password != null)
				{
					progData.mPassword = password;
				}
			}
			else if (arg.equals("-r"))
			{
				String readTimeout = args[++i];
				progData.mReadTimeout = Long.parseLong(readTimeout);
			}
			else if (arg.equals("-s"))
			{
				String mStatsInterval = args[++i];
				progData.mStatsInterval = Long.parseLong(mStatsInterval);
			}
			else if (arg.equals("-c"))
			{
				progData.mConflationIndicator = true;
			}
			else if (arg.equals("-Q"))
			{
				String queueSizeInMegaBytes = args[++i];
				progData.queueSizeInMegaBytes = Integer.parseInt(queueSizeInMegaBytes);
			}
			else if (arg.equals("-I"))
			{
				String mReqQueueSize = args[++i];
				progData.mReqQueueSize = Integer.parseInt(mReqQueueSize);
			}
			else if (arg.equals("-a"))
			{
				String mConflInterval = args[++i];
				progData.mConflInterval = Integer.parseInt(mConflInterval);
			}			
			else if (arg.equals("-n"))
			{
				progData.mNatFile = args[++i];
			}
			else if (arg.equals("-t")) {
				String mConflType = args[++i];
				progData.mConflType = Integer.parseInt(mConflType);
			}
			else if (arg.equals("-T")) {
				String mQueueThreshold = args[++i];
				progData.mQueueThreshold = Integer.parseInt(mQueueThreshold);
			}
			else if (arg.equals("-j")) {
				String mJitThreshold = args[++i];
				progData.mJitThreshold = Integer.parseInt(mJitThreshold);
			}
			else if (arg.equals("-C"))
			{
				String mMaxCspThreads = args[++i];
				progData.mMaxCspThreads = Integer.parseInt(mMaxCspThreads);
			}
			else if (arg.equals("-U"))
			{
				String mMaxUserThreads = args[++i];
				progData.mMaxUserThreads = Integer.parseInt(mMaxUserThreads);
			}
			else if (arg.equals("-P"))
			{
				String ip = args[++i];
				String port = args[++i];
				String hoststring = String.format("%s:%s", ip, port);

				if (primaryPorts.contains(Integer.parseInt(port)))
				{
					throw new IllegalArgumentException(String.format("Primary port (%s) repeated ", port));
				}

				primaryPorts.add(Integer.parseInt(port));

				if (!progData.getmPrimaryConn().contains(hoststring))
				{
					progData.getmPrimaryConn().add(hoststring);
				}
				else
				{
					throw new IllegalArgumentException(String.format("Duplicate primary hoststring ", hoststring));
				}
			}
			else if (arg.equals("-B"))
			{
				String ip = args[++i];
				String port = args[++i];
				String hoststring = String.format("%s:%s", ip, port);

				if (backupPorts.contains(Integer.parseInt(port)))
				{
					throw new IllegalArgumentException(String.format("Backup port (%s) is repeated ", port));
				}

				backupPorts.add(Integer.parseInt(port));
				if (!progData.getmBackupConn().contains(hoststring))
				{
					progData.getmBackupConn().add(hoststring);
				}
				else
				{
					throw new IllegalArgumentException(String.format("Duplicate backup hoststring ", hoststring));
				}
			}
			else if (arg.equals("-w"))
			{
				progData.mWatchlist = true;
			}
			else if (arg.equals("-W"))
			{
				progData.mWatchlistSize = Long.valueOf(args[++i]);
			}
			else
			{
				unknowArgsPassed = true;
				System.out.println("Unknown argument passed, Ignoring " + arg);
			}
		}
		
		if (args.length > 0) 
		{
			progData.setmFileName(args[args.length - 1]);
		}
		return unknowArgsPassed;
	}

	public static HostConfig buildHostConfig(String hostInfoStr, boolean isBackup)
	{
		HostConfig hostConfig = new HostConfig(hostInfoStr);// "198.190.11.21:4001");
		hostConfig.set(Parameters.BACKUP_BOOL, String.valueOf(isBackup));
		return hostConfig;
	}

	public static void buildConnectionConfig(ProgData progData, ConnectionConfig connectionConfig) {
		connectionConfig.set(Parameters.CONFLATION_INDICATOR_BOOL, progData.mConflationIndicator);
		connectionConfig.set(Parameters.COMPRESSION_BOOL, progData.mCompressedData);

		String connTimeout = System.getProperty("connection.timeout");
		if (connTimeout != null && !"".equals(connTimeout.trim())) {
			long connTimeoutLongVal = Long.valueOf(connTimeout);
			if (connTimeoutLongVal > 0) {
				connectionConfig.set(Parameters.CONNECTION_TIMEOUT_LONG, connTimeoutLongVal);
			}
		}

		if (progData.mReadTimeout >= -1) {
			connectionConfig.set(Parameters.READ_TIMEOUT_LONG, progData.mReadTimeout);
		}

		if (progData.queueSizeInMegaBytes > 0) {
			connectionConfig.set(Parameters.QUEUE_SIZE_LONG, progData.queueSizeInMegaBytes);
		}

		if (progData.mNatFile != null)
			ClientUtils.parseNatFile(connectionConfig, progData.mNatFile);

		if (progData.mConflInterval != -1)
			connectionConfig.set(Parameters.CONFLATION_INTERVAL_LONG, progData.mConflInterval);

		if (progData.mConflType != -1)
			connectionConfig.set(Parameters.CONFLATION_TYPE_LONG, progData.mConflType);

		if (progData.mJitThreshold > -1)
		{
			if (progData.mConflType != 3 && progData.mConflType != 4) {
				LOGGER.warning("Set JIT threshold with non-JIT conflation; threshold will be ignored");
			}
			connectionConfig.set(Parameters.JIT_CONFLATION_THRESHOLD_PERCENT_LONG, progData.mJitThreshold);
		}
	}

	public static HostConfig buildHostConfig(ProgData progData, String remoteHost, short remotePort, boolean isBackup, ConnectionConfig connectionConfig)
	{
		HostConfig hostConfig = new HostConfig(remoteHost, remotePort, connectionConfig);// "198.190.11.21:4001");
		hostConfig.set(Parameters.BACKUP_BOOL, String.valueOf(isBackup));
		return hostConfig;
	}

	public static int getCspThreadNbr(Map<String, String> argsMap)
	{
		if (argsMap.containsKey("-M") && argsMap.containsKey("-C"))
		{
			return Integer.parseInt(argsMap.get("-C"));
		}
		else
		{
			return 1;
		}
	}

	public static int getUserSideThreadNbr(Map<String, String> argsMap)
	{
		if (argsMap.containsKey("-M") && argsMap.containsKey("-U"))
		{
			return Integer.parseInt(argsMap.get("-U"));
		}
		else
		{
			return 1;
		}
	}

	public static void setupDataLogger(String name, Level level, String outputFile) throws IOException
	{
		Logger log = Logger.getLogger(name);
		log.setLevel(level);

		StreamHandler handler;
		if (outputFile == null)
		{
			log.setUseParentHandlers(false);
			handler = new ConsoleHandler();
			handler.setLevel(level);
			handler.setFormatter(new DataLoggerFormater());
		}
		else
		{
			log.setUseParentHandlers(false);
			handler = new FileHandler(outputFile);
			handler.setLevel(level);
			handler.setFormatter(new DataLoggerFormater());
		}

		log.addHandler(handler);
	}

	public static void setUpDataLogger(ProgData progData)
	{
		Level dataloggerLevel = Level.INFO;
		if (progData.mQuiet)
		{
			dataloggerLevel = Level.OFF;
		}

		try
		{
			setupDataLogger("DataLogger", dataloggerLevel, progData.outputToFile);
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
	}

	public static String exceptionToString(Throwable exe)
	{
		StringWriter sw = new StringWriter();
		PrintWriter pw = new PrintWriter(sw);
		pw.println();
		exe.printStackTrace(pw);
		pw.close();
		return sw.toString();
	}

	// Assume format of each line of file is:
	// <CSP IP>,<local IP>
	public static void parseNatFile(ConnectionConfig connectionConfig, String natFilename)
	{
		BufferedReader reader = null;
		try
		{
			LOGGER.info(String.format("Looking up: %s natfile in the classpath.", natFilename));

			String line = null;
			URL natConfigFileUrl = ClassLoader.getSystemResource(natFilename);
			if(natConfigFileUrl == null){
				LOGGER.warning("cf-java api-client cannot find the NAT file " + natFilename + " in the classpath.");
				return;
			}
			reader = new BufferedReader(new InputStreamReader(natConfigFileUrl.openStream()));

			while ((line = reader.readLine()) != null)
			{

				if (line.trim().equals("") || line.startsWith("#"))
				{
					continue;
				}
				else
				{
					String[] lineVals = line.split(",");
					if (lineVals.length < 2)
					{
						LOGGER.info(String.format("Invalid line (missing comma): %s", line));
						continue;
					}

					String ipCsp = lineVals[0];
					String ipClient = lineVals[1];

					connectionConfig.addNATPair(ipCsp, ipClient);
				}
			}
		}
		catch (Exception e)
		{
			LOGGER.severe("Exception while reading NAT file " + exceptionToString(e));
		}
		finally
		{
			FileUtil.closeReader(reader);
		}
	}

	public static void main(String[] args)
	{
		Logger log = Logger.getLogger(ClientUtils.class.getName());
		try
		{
			setupDataLogger(ClientUtils.class.getName(), Level.INFO, "TestLog");
			for (int i = 0; i < 1000000000; i++)
			{
				System.out.println("Storing msg with id " + i);
				log.info("TestLog" + i);
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}
}
