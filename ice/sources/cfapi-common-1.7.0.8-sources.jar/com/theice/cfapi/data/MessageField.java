package com.theice.cfapi.data;

public interface MessageField
{

	/**
	 * Returns the CTF token name of the current token-value pair
	 *
	 * @return String containing the CTF token name, "UNKNOWN" if unknown CTF token name
	 *
	 */
	public String getTokenName();

	/**
	 * Returns the CTF token nnumber of the current token-value pair
	 *
	 * @return int containing the CTF token id; -1 if no current token-value pair
	 *
	 */
	public int getTokenNumber();

	/**
	 * Returns the type of the value for this token-value pair
	 *
	 * @return ValueType of the value
	 */
	public ValueTypes getValueType();

	/**
	 * If valueType==INT64, user can extract the value as an int64_t
	 *
	 * @return int64_t containing the current value
	 */
	public Long getValueAsLong();

	/**
	 * If valueType==DOUBLE or DATETIME, user can extract the value as a double
	 *
	 * @return double containing the current value
	 */
	public Double getValueAsDouble();

	/**
	 * If valueType==STRING, user can extract the value as a std::string
	 *
	 * @return std::string containing the current value
	 */
	public String getValueAsString();

	/**
	 * If valueType==DATETIME, user can extract the value as a DateTime object
	 *
	 * @return DateTime object containing the current value Note: this DateTime object must be freed by the caller
	 */
	public DateTime getValueAsDateTime();

	Object getValue();

	boolean isValueNull();

}