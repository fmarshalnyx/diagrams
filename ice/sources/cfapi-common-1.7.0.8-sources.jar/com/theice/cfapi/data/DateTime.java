package com.theice.cfapi.data;

/**
 * Communicates Date and/or Time information.
 */
public interface DateTime
{

	/**
	 * Indicates presence of the Date values
	 * 
	 * @return true if Date is present, false if Date is not present
	 */
	boolean hasDate();

	/**
	 * Returns DateTime.Date values when Date information is present (hasDate() returns true)
	 * 
	 * @return DateTime.Date object
	 */
	Date date();

	/**
	 * Indicates presence of the Time values
	 * 
	 * @return true if Time is present, false if Time is not present
	 */
	boolean hasTime();

	/**
	 * Returns DateTime.Time values when Time information is present (hasTime() returns true)
	 * 
	 * @return DateTime.Time object
	 */
	Time time();

	/**
	 * Contains date specific values. This information is obtained via the DateTime.date() method
	 */
	interface Date
	{
		/**
		 * Returns the month of the year, where January == value 1.
		 * 
		 * @return numeric value representing month of the year
		 */
		int month();

		/**
		 * Returns the day of the month
		 * 
		 * @return numeric value representing day of the month
		 */
		int day();

		/**
		 * Returns the year
		 * 
		 * @return numeric value representing the year, as a four digit year (e.g. 2016)
		 */
		int year();

	}

	/**
	 * Contains time specific values. This information is obtained via the DateTime.time() method
	 */
	interface Time
	{

		/**
		 * Returns the hour of the day
		 * 
		 * @return numeric value representing hour of the day
		 */
		int hour();

		/**
		 * Returns the minute of the hour
		 * 
		 * @return numeric value representing the minute of the hour
		 */
		int minute();

		/**
		 * Returns the second of the minute
		 * 
		 * @return numeric value representing seconds of the minute
		 */
		int second();

		/**
		 * Returns the millisecond of the second
		 * 
		 * @return numeric value representing milliseconds of the second
		 */
		long millisecond();

		/**
		 * Returns the microsecond of the millisecond
		 * 
		 * @return numeric value representing microsecond of the millisecond
		 */
		long microsecond();

	}

	/**
	 * Use the Date's year() to get the corresponding value.
	 * 
	 * @return
	 */
	int getYear();

	/**
	 * Use the Date's month() to get the corresponding value.
	 * 
	 * @return
	 */
	int getMonth();

	/**
	 * Use the Date's day() to get the corresponding value.
	 * 
	 * @return
	 */
	int getDay();

	/**
	 * Use the Time's hour() to get the corresponding value.
	 * 
	 * @return
	 */
	int getHour();

	/**
	 * Use the Time's minute() to get the corresponding value.
	 * 
	 * @return
	 */
	int getMinute();

	/**
	 * Use the Time's second() to get the corresponding value.
	 * 
	 * @return
	 */
	int getSeconds();

	/**
	 * Use the Time's millisecond() to get the corresponding value.
	 * 
	 * @return
	 */
	long getMillisec();

	/**
	 * Use the Time's microsecond() to get the corresponding value.
	 * 
	 * @return
	 */
	long getMicrosec();

	/**
	 * instead of this use the MessageReader's reader.getValueAsDouble() to get the raw double value for a dattetime.
	 * 
	 * @return
	 */
	@Deprecated
	double getRawDateTime();

	/**
	 * This returns the complete DateTime in millis in epoch format.
	 * 
	 * @return
	 */
	long getDateTimeInMillis();
}