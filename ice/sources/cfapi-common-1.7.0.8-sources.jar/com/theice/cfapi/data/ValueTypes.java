package com.theice.cfapi.data;


public enum ValueTypes {

   UNKNOWN,
   INT64,
   STRING,
   DOUBLE,
   DATETIME;
}
