package com.theice.cfapi.log.formatter;

import java.util.logging.LogRecord;
import java.util.logging.SimpleFormatter;

public class DataLoggerFormater extends SimpleFormatter {

    @Override
    public String format(LogRecord record) {
        StringBuilder builder = new StringBuilder();
//        builder.append(record.getLevel() + ": ");
        builder.append(formatMessage(record));
        builder.append(System.lineSeparator());
        return builder.toString();
    }

}
