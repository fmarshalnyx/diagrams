package com.theice.cfapi.log.formatter;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.Date;
import java.util.logging.LogRecord;
import java.util.logging.SimpleFormatter;

import com.theice.cfapi.log.RequestContextUtils;

public class ApiLogFormatter extends SimpleFormatter
{
	private static final String format = System.getProperty("java.util.logging.SimpleFormatter.format");

	public synchronized String format(LogRecord record)
	{
		Date dat = new Date();
		dat.setTime(record.getMillis());

		String requestId = RequestContextUtils.get();
		StringBuilder sourceSb = new StringBuilder();
		if (record.getSourceClassName() != null)
		{
			sourceSb.append(record.getSourceClassName());
			if (record.getSourceMethodName() != null)
			{
				sourceSb.append(" ").append(record.getSourceMethodName());
			}

			if (requestId != null)
				sourceSb.append(String.format("[%s]", requestId));
		}
		else
		{
			sourceSb.append(record.getLoggerName());
		}

		String message = formatMessage(record);
		String throwable = "";
		if (record.getThrown() != null)
		{
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			pw.println();
			record.getThrown().printStackTrace(pw);
			pw.close();
			throwable = sw.toString();
		}
		return String.format(format, dat, sourceSb.toString(), Thread.currentThread().getName(), record.getLevel().getLocalizedName(), message, throwable);
	}
}
