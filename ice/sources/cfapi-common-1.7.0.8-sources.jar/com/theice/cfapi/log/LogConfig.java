package com.theice.cfapi.log;

import com.theice.cfapi.log.formatter.ApiLogFormatter;

import java.io.File;
import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.logging.*;

public class LogConfig
{

	private static final Logger LOG = Logger.getLogger(LogConfig.class.getName());

	public static String buildLogfile(String logDir, String logFileName)
	{
		System.out.println("logFileName: " + logFileName + ", logDir: " + logDir);
		String dateStr = LocalDate.now().format(DateTimeFormatter.ofPattern("yyyyMMdd"));
		String timeStr = LocalDateTime.now().format(DateTimeFormatter.ofPattern("HHmmss"));
		String logFileAppenderName = String.format("%s_%s_%s.log", dateStr, logFileName, timeStr);

		if (logDir != null && !"".equals(logDir.trim()))
		{
			logFileAppenderName = logDir + File.separator + logFileAppenderName;
		}
		System.out.println("Initializing file appender: " + logFileAppenderName);

		return logFileAppenderName;
	}

	public static void setupAPILogging(Level level, String logDir, String outputFileName) throws IOException
	{
		String name = "com.theice.cfapi";
		System.setProperty("java.util.logging.SimpleFormatter.format", "%1$tY-%1$tm-%1$td %1$tH:%1$tM:%1$tS.%1$tL %4$-7s [%3$s] (%2$s) %5$s %6$s%n");
		StreamHandler handler;
		String logFilePath = null;
		if (outputFileName == null)
		{
			handler = new ConsoleHandler();
			handler.setLevel(level);
			handler.setFormatter(new ApiLogFormatter());
		}
		else
		{
			logFilePath = buildLogfile(logDir, outputFileName);
			handler = new FileHandler(logFilePath);
			handler.setLevel(level);
			handler.setFormatter(new ApiLogFormatter());
		}

		Logger log = Logger.getLogger(name);
		for (Handler h : log.getHandlers()) {
			h.setLevel(level);
			System.out.println("Removing Handler class " + h.getClass().getName());
//			h.setFormatter(new ApiLogFormatter());
			log.removeHandler(h);
		}

		log.setLevel(level);
		log.setUseParentHandlers(false);
		log.addHandler(handler);

		LOG.info("API logging started for IDC API Client.");
//		setupEsignalDBCAPILogging(level, "cmdbcapiLog");
	}

	// <Logger name="com.esignal.jstandard" level="off">
	// <AppenderRef ref="console"/>
	// <AppenderRef ref="ASYNC"/>
	// </Logger>
	// <Logger name="CPLUSPLUSLOG" level="off">
	// <AppenderRef ref="cplusplusconsole"/>
	// </Logger>
//	public static void setupEsignalDBCAPILogging(Level level, String outputFile) throws IOException
//	{
//		LOG.info("Setting esignalCMDBCApi logger for IDC API Client that will log the data to " + outputFile);
//
//		System.setProperty("java.util.logging.SimpleFormatter.format", "%1$tY-%1$tm-%1$td %1$tH:%1$tM:%1$tS.%1$tL %4$-7s [%3$s] (%2$s) %5$s %6$s%n");
//		StreamHandler handler;
//		if (outputFile == null)
//		{
//			handler = new ConsoleHandler();
//			handler.setLevel(level);
//			handler.setFormatter(new ApiLogFormatter());
//		}
//		else
//		{
//			handler = new FileHandler(outputFile);
//			handler.setLevel(level);
//			handler.setFormatter(new ApiLogFormatter());
//		}
//
//		createLoggerWithHandler(level, "com.esignal.jstandard", handler);
//		createLoggerWithHandler(level, "CPLUSPLUSLOG", handler);
//		LOG.info("EsignalCMDBCAPI logging started for IDC API Client.");
//	}

	private static void createLoggerWithHandler(Level level, String name, StreamHandler handler)
	{
		LOG.info("Creating " + name + " logger.");
		Logger log = Logger.getLogger(name);
		for (Handler h : log.getHandlers())
		{
			log.removeHandler(h);
		}
		log.setLevel(level);
		log.setUseParentHandlers(false);
		log.addHandler(handler);
	}
}
