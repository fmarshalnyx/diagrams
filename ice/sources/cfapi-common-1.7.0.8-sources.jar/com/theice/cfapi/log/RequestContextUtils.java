package com.theice.cfapi.log;

public class RequestContextUtils
{

	private static final ThreadLocal<String> thRequestContext = new ThreadLocal<>();

	public static void set(String requestId)
	{
		thRequestContext.set(requestId);
	}
	
	public static String get()
	{
		return thRequestContext.get();
	}

	public static void remove()
	{
		thRequestContext.remove();
	}

	public static String buildRequestId(Object... args) {
		StringBuilder reqIdStr = new StringBuilder();
		for (Object arg : args) {
			reqIdStr.append(arg);
			if (reqIdStr.lastIndexOf("~") == -1) {
				reqIdStr.append("~");
			}
		}
		return reqIdStr.toString();
	}

	public static void buildAndSetRequestId(Object... args)
	{
		set(buildRequestId(args));
	}

}
