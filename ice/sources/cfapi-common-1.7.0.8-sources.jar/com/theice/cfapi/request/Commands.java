package com.theice.cfapi.request;

public enum Commands {

	SUBSCRIBE("Subscribe"), UNSUBSCRIBE("Unsubscribe"), QUERYDEPTH("QueryDepth"), QUERYSNAP("QuerySnap"),
	QUERYWILDCARD("QueryWildCard"), QUERYDEPTHANDSUBSCRIBE("QueryDepthAndSubscribe"),
	QUERYSNAPANDSUBSCRIBE("QuerySnapAndSubscribe"), LISTENUMERATION("ListEnumeration"),
	LISTAVAILABLETOKENS("ListAvailableTokens"), LISTADMINISTRATIONINFO("ListAdministrationInfo"),
	LISTEXTENDEDEXCHANGEINFO("ListExtendedExchangeInfo"), SELECTUSERFILTERTOKENS("SelectUserFilterTokens"),
	LISTSUBSCRIBEDSYMBOLS("ListSubscribedSymbols"), QUERYXREF("QueryXref"), LISTUSERPERMISSION("ListUserPermission"),
	SETCONFLATIONINTERVAL("SetConflationInterval"), SUBSCRIBEWILDCARD("SubscribeWildCard"),
	QUERYSNAPANDSUBSCRIBEWILDCARD("QuerySnapAndSubscribeWildCard"), UNSUBSCRIBEWILDCARD("UnsubscribeWildCard"),
	ADDALTERNATEINDEX("AddAlternateIndex"), GETSOURCEPORTDETAILS("GetSourcePortDetails"),
	SETL2CONFLATIONINTERVAL("SetL2ConflationInterval");

	//This field is added just to provide backward compatability.
	//It would store the actual command string a case-sensitive string.
	private String commandStr;

	Commands(String commandStr) {
		this.commandStr = commandStr;
	}

	public static Commands getCommandByName(String commandStr) {
		for (Commands r : values()) {
			if (r.toString().equalsIgnoreCase(commandStr)) {
				return r;
			}
		}
		return null;
	}

	/**
	 * instead of using this method call enum's name() or toString()
	 * 
	 * @return
	 */
	public String getCommandString() {
		return this.commandStr;
	}
}
