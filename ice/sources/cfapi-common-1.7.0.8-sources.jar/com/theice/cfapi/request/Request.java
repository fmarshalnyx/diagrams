package com.theice.cfapi.request;

import java.util.logging.Logger;

import com.theice.cfapi.session.Session;

/*
 * Move away from using this class, instead of Request class using the IRequest.
 * 
 * */

@Deprecated
public class Request
{
	private static final Logger log = Logger.getLogger(Request.class.getName());

	protected int srcid = -1;
	protected String symbol;
	protected long queryTag;
	protected StringBuilder params = new StringBuilder();
	protected Session session;
	protected Commands command;
	protected boolean isTagSet;
	protected boolean isCmdSet;
	protected boolean resubCspStatus;
	protected boolean resubHB;

	public Request()
	{
		super();
	}

	public Request(Session session)
	{
		this.session = session;
	}

	/**
	 * set command for CSP request message.
	 *
	 * @param command
	 *            An enumerated value corresponding to the command to send to the CSP with this Request
	 */
	public void setCommand(Commands command)
	{
		this.command = command;

		if (this.command != null)
		{
			String commandStr = String.format("5022=%s|", command.getCommandString());
			params.append(commandStr);
			isCmdSet = true;
		}
	}

	/**
	 * A CSP request message. Should be populated with the desired parameters
	 *
	 * @param parameter
	 *            An enumerated value corresponding to one of the RequestParameters known to the API implementation
	 * @param value
	 *            The value to set the parameter to. This method is used when setting a parameter to a string type.
	 */
	public void add(int parameter, int value)
	{
		switch (parameter)
		{
		case 5022: // command
		case 5026: // tag
			log.warning(String.format("Invalid parameter (%d) passed to Request::add", parameter));
			break; // discard
		case 4: // srcid -- save for routing
			srcid = value;
		default: // write into CTF format....
			params.append(String.format("%d=%d|", parameter, value));
		}
	}

	/**
	 * A CSP request message. Should be populated with the desired parameters
	 *
	 * @param parameter
	 *            An enumerated value corresponding to one of the RequestParameters known to the API implementation
	 * @param value
	 *            The value to set the parameter to. This method is used when setting a parameter to a string type.
	 */
	public void add(int parameter, String value)
	{
		log.info(String.format("add: %d=%s", parameter, value));

		switch (parameter)
		{
		case 5022: // command
		case 5026: // tag
			log.warning(String.format("Invalid parameter (%d) passed to Request::add", parameter));
			break; // discard
		case 4: // srcid -- save for routing
		case 5: // symbol -- save for routing
			if (parameter == 4)
			{
				srcid = Integer.parseInt(value);
			}
			else if (parameter == 5)
			{
				symbol = value;
			}
		default: // write into CTF format....
			params.append(String.format("%d=%s|", parameter, value));
		}
	}

	public int getSrcid()
	{
		return srcid;
	}

	public String getSymbol()
	{
		return symbol;
	}

	public Commands getCommand()
	{
		return command;
	}

	public long generateAndSetQueryTag()
	{
		this.queryTag = session.generateTag();
		params.append(String.format("5026=%d|", queryTag));
		isTagSet = true;
		return queryTag;
	}

	public boolean isTagSet()
	{
		return isTagSet;
	}

	public long getQueryTag()
	{
		return queryTag;
	}

	public StringBuilder getParams()
	{
		return params;
	}

	public Session getSession()
	{
		return session;
	}

	public boolean isCmdSet()
	{
		return isCmdSet;
	}

	public boolean isResubCspStatus()
	{
		return resubCspStatus;
	}

	public boolean isResubHB()
	{
		return resubHB;
	}

	public void setResubCspStatus(boolean resubCspStatus)
	{
		this.resubCspStatus = resubCspStatus;
	}

	public void setResubHB(boolean resubHB)
	{
		this.resubHB = resubHB;
	}
}