package com.theice.cfapi.request;

/**
 * Request Parameters
 */

public enum RequestParameters {
	COMMAND(5022), CUSIP(3123), SEDOL(3126), ISIN(3125), ENUM_SRC_ID(4), ENUM_SRC_UNDERLYING_ID(3130), SYMBOL_TICKER(5),
	SYMBOL_UNDERLYING_TICKER(3083), CONFLATION(2035), CTF_TOKEN_NAME(5010), CTF_TOKEN_NUM(5035),
	SYMBOL_BLOOMBERG_TICKER(3950), SYMBOL_ESIGNAL_TICKER(3958), PRODUCT_ROOT(3974), DEPTH_TYPE(5039), USER_NAME(5028),
	CONFLATION_INTERVAL(2029), CTF_FILTER_ID(5205), QUERY_REF_TAG(5052);

	private int tokenNum;

	RequestParameters(int tokenNum) {
		this.tokenNum = tokenNum;
	}

	public int getTokenNum() {
		return tokenNum;
	}

	public void setTokenNum(int tokenNum) {
		this.tokenNum = tokenNum;
	}

	public static RequestParameters getReqToken(String reqTokenStr) {

		for (RequestParameters r : values()) {
			if (r.name().equalsIgnoreCase(reqTokenStr) || String.valueOf(r.getTokenNum()).equals(reqTokenStr)) {
				return r;
			}
		}

		return null;
	}
}
