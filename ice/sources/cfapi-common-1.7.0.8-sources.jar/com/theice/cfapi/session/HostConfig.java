package com.theice.cfapi.session;

import java.util.HashMap;
import java.util.Map;
import java.util.logging.Logger;

public class HostConfig
{


	public enum Parameters
	{
		/**
		 * Is this a backup CSP? Default is false.
		 */
		BACKUP_BOOL,

		/**
		 * Use compression between CSP and API. Default is true
		 */
		COMPRESSION_BOOL,

		/**
		 * Indicate which messages are conflatable. Default is false
		 */
		CONFLATION_INDICATOR_BOOL,

		/**
		 * Maximum time to hold conflatable data (in milliseconds). Default is 1000 (ms)
		 */
		CONFLATION_INTERVAL_LONG,

		/**
		 * Is this a CSA? Default is false.
		 */
		CSA_BOOL,

		READ_TIMEOUT_LONG,

		CONNECTION_TIMEOUT_LONG,

		/**
		 * Maximum number of consecutive reconnects to the CSP without successfully initializing. Default is 5
		 */
		CONNECTION_RETRY_LIMIT_LONG,

		/**
		 * Size in megabytes of internal buffer for incoming messages from the CSP. Default is 1 (megabyte); valid range is 1-64
		 * (MB) Note: there is one queue per backend CSP, so each one will be allocated with this size
		 */
		QUEUE_SIZE_LONG,

		/**
		 * Type of conflation.  1: trade-safe (Default); 2: intervalized; 3: Just-In-Time (JIT)
		 */
		CONFLATION_TYPE_LONG,

		/**
		 * Threshold to trigger JIT conflation.  This is the percent of the buffer used before feed starts conflating. Default is 25%; valid range is 1-75.  Only valid when CONFLATION_TYPE_LONG is set to 3 (JIT).
		 */
		JIT_CONFLATION_THRESHOLD_PERCENT_LONG
	};

	private static Logger LOGGER = Logger.getLogger(HostConfig.class.getName());

	private final String hostconfigKey;
	private final String origRemoteHostIp;

	// Remote Host address gets updated by the CSP IP returned from CM and the hostInfoString.
	private String remoteHost;
	private int remotePort;
	private String hostInfoString;

	private boolean copy;
	private boolean backup;

	@Deprecated
	/** will remove this in the upcoming releases.
	 */
	private final Map<Parameters, String> parametersStringMap = new HashMap<>();
	private ConnectionConfig connectionConfig;

	public boolean isBackup() {
		return backup;
	}

	public void setBackup(boolean backup) {
		this.backup = backup;
	}

	public ConnectionConfig getConnectionConfig()
	{
		return connectionConfig;
	}

	public void setConnectionConfig(ConnectionConfig connectionConfig)
	{
		this.connectionConfig = connectionConfig;
	}

	public boolean isCopy()
	{
		return copy;
	}

	public HostConfig(String hostInfoString)
	{
		this.hostInfoString = hostInfoString;
		this.remoteHost = hostInfoString.substring(0, hostInfoString.indexOf(":"));
		this.remotePort = Integer.parseInt(hostInfoString.substring(hostInfoString.indexOf(":") + 1));
		this.hostconfigKey = this.hostInfoString;
		this.origRemoteHostIp = hostconfigKey.substring(0, hostInfoString.indexOf(":"));
	}

	public HostConfig(String remoteHost, int remotePort, ConnectionConfig connectionConfig)
	{
		this.remoteHost = remoteHost;
		this.remotePort = remotePort;
		this.hostInfoString = String.format("%s:%d", remoteHost, remotePort);
		this.connectionConfig = connectionConfig;
		this.hostconfigKey = this.hostInfoString;
		this.origRemoteHostIp = hostconfigKey.substring(0, hostInfoString.indexOf(":"));
	}

	public String getHostInfoString()
	{
		return hostInfoString;
	}

	/**
	 * Sets connection parameters. If not previously set, this will create and set value. If already set, this will replace setting
	 *
	 * @param parameter
	 *            A Parameters value that corresponds to the config value
	 * @param value
	 *            The value of the desired parameter
	 */
	public void set(Parameters parameter, String value)
	{
		parametersStringMap.put(parameter, value);
	}

	public long getLong(Parameters parameter, long defaultVal)
	{
		String val = parametersStringMap.get(parameter);

		switch (parameter)
		{
			case CONFLATION_INTERVAL_LONG:
			case CONFLATION_TYPE_LONG:
			case READ_TIMEOUT_LONG:
			case CONNECTION_TIMEOUT_LONG:
			case CONNECTION_RETRY_LIMIT_LONG:
			case QUEUE_SIZE_LONG:
			case JIT_CONFLATION_THRESHOLD_PERCENT_LONG:
			if (val != null)
			{
				return Long.parseLong(val);
			}
			else // Not found here, get it from ConnectionConfig
			{
				return connectionConfig.getLong(parameter, defaultVal);
			}
		default:
			LOGGER.warning(String.format("Invalid parameter (%s) passed to HostConfig::getLong", parameter.name()));
		}

		return defaultVal;
	}

	public boolean getBoolean(Parameters parameter, boolean defaultVal)
	{
		String val = parametersStringMap.get(parameter);
		switch (parameter)
		{
		case COMPRESSION_BOOL:
		case CONFLATION_INDICATOR_BOOL:
		case BACKUP_BOOL:
			if (val != null)
			{
				return Boolean.valueOf(val);
			}
			else // Not found here, get it from ConnectionConfig
			{
				return connectionConfig.getBoolean(parameter, defaultVal);
			}
		default:
			LOGGER.warning(String.format("Invalid parameter (%s) passed to ConnectionConfigImpl::getBoolean", parameter.name()));
		}

		return defaultVal;
	}

	public String getKey()
	{
		return hostconfigKey;
	}

	public void copyParameters(HostConfig srcHost)
	{
		this.copy = true;
		this.parametersStringMap.putAll(srcHost.parametersStringMap);
		this.backup = srcHost.isBackup();
	}

	// Remote Host address gets updated by the CSP IP returned from CM
	public String getRemoteHost()
	{
		return remoteHost;
	}
	
	public String getOrigRemoteHostIp()
	{
		return origRemoteHostIp;
	}

	public int getRemotePort()
	{
		return remotePort;
	}

	public String getLocalIp(String ipCsp)
	{
		if (connectionConfig != null)
		{
			return connectionConfig.getLocalIp(ipCsp);
		}
		else
		{
			return null;
		}
	}

	public String getCspIp(String ipLocal)
	{
		if (connectionConfig != null)
		{
			return connectionConfig.getCsplIp(ipLocal);
		}
		else
		{
			return null;
		}
	}

	public void updateIpAddress(String m_csp_ip_addr)
	{
		this.remoteHost = m_csp_ip_addr;
		this.hostInfoString = String.format("%s:%d", remoteHost, remotePort);
	}

	public boolean reset() {
		if (!this.hostconfigKey.equals(this.hostInfoString)) {
			LOGGER.info("Updating hostConfig to original address as hostInfoString: " + hostInfoString + " is different from hostconfigKey: " + hostconfigKey);
			this.hostInfoString = this.hostconfigKey;
			this.remoteHost = this.origRemoteHostIp;
			return true;
		}
		return false;
	}
	
	@Override
	public int hashCode()
	{
		final int prime = 31;
		int result = 1;
		result = prime * result + ((hostconfigKey == null) ? 0 : hostconfigKey.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj)
	{
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		HostConfig other = (HostConfig) obj;
		if (hostconfigKey == null)
		{
			if (other.hostconfigKey != null)
				return false;
		}
		else if (!hostconfigKey.equals(other.hostconfigKey))
			return false;
		return true;
	}

}
