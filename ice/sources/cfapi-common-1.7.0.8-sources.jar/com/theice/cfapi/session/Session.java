package com.theice.cfapi.session;

import com.theice.cfapi.event.MessageEventHandler;
import com.theice.cfapi.event.SessionEventHandler;
import com.theice.cfapi.event.StatisticsEventHandler;
import com.theice.cfapi.request.Commands;
import com.theice.cfapi.request.IRequest;
import com.theice.cfapi.request.Request;
import com.theice.cfapi.user.UserInfo;

/**
 * User: dkim Date: 3/1/2017 Time: 3:38 PM
 */
public interface Session
{

    enum SessionStates
	{
		SESSION_UNAVAILABLE, SESSION_ESTABLISHED, SESSION_RECOVERY
	}

	public SessionStates getState();

	@Deprecated
	public SessionConfig getSessionConfig();

	@Deprecated
	public ConnectionConfig getConnectionConfig();

	@Deprecated
	public void setSessionConfig(SessionConfig sessionConfig);

	@Deprecated
	public void setConnectionConfig(ConnectionConfig connectionConfig);

	public UserInfo getUserInfo();

	@Deprecated
	public void setUserInfo(UserInfo userInfo);

	public SessionEventHandler getSessionEventHandler();

	public void setSessionEventHandler(SessionEventHandler sessionEventHandler);

	public MessageEventHandler getMessageEventHandler();

	public void setMessageEventHandler(MessageEventHandler messageEventHandler);

	public boolean start();

	public boolean stop();

	/**
	 * Instead of calling this method use createNewRequest() which returns a request of type IRequest.
	 * 
	 * @return Request
	 */
	@Deprecated
	public Request createRequest();

	/**
	 * Instead of calling this method to send request use the send(IRequest req) which needs an instance of type IRequest class.
	 * 
	 * @param req
	 * @return
	 */
	@Deprecated
	public long send(Request req);

	/**
	 * Create a new Request object of type IRequest
	 * 
	 * @return
	 */
	public IRequest createNewRequest();

	/**
	 *
	 * @param req
	 * 			Request indicating identifying information for desired content
	 * @return handle associated with this request (the auto-generated 5026/QUERY.TAG for this request)
	 *
	 * If the Session's input queue is full (non-watchlist mode), send will fail and return a tag of 0.
	 *
	 */
	public long send(IRequest req);

	public String getRetCodeDesc(int statusVal);

	public long generateTag();

	public boolean isQueryCommand(Commands command);

	public void registerStatisticsEventHandler(StatisticsEventHandler statsEH, int mStatsInterval);
}
