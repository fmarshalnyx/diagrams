package com.theice.cfapi.session;

/**
 * Type of conflation.  1: trade-safe (Default); 2: intervalized; 3: Just-In-Time (JIT)
 */

public enum ConflationType {

    TRADE_SAFE(1),
    INTERVALIZED(2),
    JUST_IN_TIME(3),
    JIT_INTERVALIZED(4);

    private int confTypeAsInt;

    ConflationType(int confTypeAsInt) {
        this.confTypeAsInt = confTypeAsInt;
    }

    public int getConfTypeAsInt() {
        return confTypeAsInt;
    }

    public void setConfTypeAsInt(int confTypeAsInt) {
        this.confTypeAsInt = confTypeAsInt;
    }

    public static boolean isConflationTypeValid(int conflationTypeAsInt){
        for(ConflationType conflationType : values()){
            if(conflationType.getConfTypeAsInt() == conflationTypeAsInt){
                return  true;
            }
        }
        return  false;
    }

}
