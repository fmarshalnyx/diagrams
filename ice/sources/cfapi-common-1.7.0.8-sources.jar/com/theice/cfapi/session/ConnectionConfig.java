package com.theice.cfapi.session;

import com.theice.cfapi.session.HostConfig.Parameters;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ConnectionConfig
{

	private static final Logger LOGGER = Logger.getLogger(ConnectionConfig.class.getName());

	public static long DEFAULT_CONNECTION_TIMEOUT = 5;
	public static int DEFAULT_CONFLATION_INTERVAL = 1000;
	public static int DEFAULT_JIT_CONFLATION_THRESHOLD_PERCENT = 25;

	public static int MIN_JIT_THRESHOLD = 1;
	public static int MAX_JIT_THRESHOLD = 75;

	private boolean compression = true;
	private boolean conflationIndicator;
	private int conflationInterval;
	private int conflationType;
	private long readTimeout;
	private long connectionTimeout;
	private long connectionRetryLimit = 5;
	private long queueSize;
	private int jitThreshold;

	private ConcurrentMap<String, String> natMap1 = new ConcurrentHashMap<>();
	private ConcurrentMap<String, String> natMap2 = new ConcurrentHashMap<>();

	private final Map<String, HostConfig> hostConfigMap = Collections.synchronizedMap(new LinkedHashMap<String, HostConfig>());
	private final List<HostConfig> primaryHostConfigs = Collections.synchronizedList(new ArrayList<>());
	private final List<HostConfig> backupHostConfigs = Collections.synchronizedList(new ArrayList<>());
	private final Set<String> m_CMList = Collections.synchronizedSet(new LinkedHashSet<>());

	private final Set<Integer> primaryPorts = Collections.synchronizedSet(new LinkedHashSet<>());
	private final Set<Integer> backupPorts = Collections.synchronizedSet(new LinkedHashSet<>());

	public ConnectionConfig()
	{
		// set defaults
		this.compression = true;
		this.conflationIndicator = false;
		this.conflationInterval = DEFAULT_CONFLATION_INTERVAL;
		this.conflationType = ConflationType.TRADE_SAFE.getConfTypeAsInt();//default is trade-safe
		this.jitThreshold = DEFAULT_JIT_CONFLATION_THRESHOLD_PERCENT;	//default is 25%
		this.readTimeout = DEFAULT_CONNECTION_TIMEOUT; // default is 5 seconds
		this.connectionTimeout = DEFAULT_CONNECTION_TIMEOUT; // default is 5 seconds
		this.connectionRetryLimit = 5;
		this.queueSize = 1; // default is 1MB
	}

	public void setHostconfig(HostConfig hostConfig)
	{
		// split hostInfoString into separate ipaddr and port
		hostConfig.setConnectionConfig(this);

		// get the Primary / backup (CM, port) pair
		boolean isBackup = hostConfig.getBoolean(HostConfig.Parameters.BACKUP_BOOL, false);
		// CEF/OPRA changes
		if (isBackup)
		{
			LOGGER.info(
					String.format("ConnectionConfigImpl::setHostconfig: Recording new hostConfig (%s) as backup connection.", hostConfig.getHostInfoString()));
			backupHostConfigs.add(hostConfig);
			m_CMList.add(hostConfig.getOrigRemoteHostIp());
			backupPorts.add(hostConfig.getRemotePort());
		}
		else
		{
			LOGGER.info(
					String.format("ConnectionConfigImpl::setHostconfig: Recording new hostConfig (%s) as primary connection.", hostConfig.getHostInfoString()));
			primaryHostConfigs.add(hostConfig);
			m_CMList.add(hostConfig.getOrigRemoteHostIp());
			primaryPorts.add(hostConfig.getRemotePort());
		}
	}

	public HostConfig getHostConfig(String hostInfoString)
	{
		HostConfig hostConfig = hostConfigMap.get(hostInfoString);
		if (hostConfig != null)
		{
			if (LOGGER.isLoggable(Level.FINEST))
			{
				LOGGER.finest(
						String.format("ConnectionConfigImpl::getHostConfig(ENTRY): HostConfig object found mapped to hostInfoString (%s)", hostInfoString));
			}
			return hostConfig;
		}
		else
		{
			LOGGER.info(String.format("ConnectionConfigImpl::getHostConfig(ENTRY): No HostConfig object mapped to hostInfoString (%s)", hostInfoString));
			return null;
		}
	}

	public HostConfig createHostConfigIfNotAvailable(String hostInfoString)
	{
		HostConfig hostConfig = hostConfigMap.get(hostInfoString);
		if (hostConfig != null)
		{
			LOGGER.info(String.format("ConnectionConfigImpl::getHostConfig(ENTRY): HostConfig object found mapped to hostInfoString (%s)", hostInfoString));
			return hostConfig;
		}
		else // Not found, create it
		{
			LOGGER.info(String.format("ConnectionConfigImpl::getHostConfig(ENTRY): Creating a new hostConfig mapped to hostInfoString (%s)", hostInfoString));
			// split hostInfoString into separate ipaddr and port
			HostConfig newHostConfig = new HostConfig(hostInfoString);
			newHostConfig.setConnectionConfig(this);
			newHostConfig.copyParameters(getPrimaryHostConfig(0)); // clone from the Primary HostConfig

			recordHostConfig(hostInfoString, newHostConfig);
			return newHostConfig;
		}
	}

	public void recordHostConfig(String hostInfoString, HostConfig hostConfig)
	{
		// split hostInfoString into separate ipaddr and port
		hostConfig.setConnectionConfig(this);

		hostConfigMap.put(hostInfoString, hostConfig);

		LOGGER.info(String.format("new hostConfigMap entry for (%s); hostConfigMap.size()=%d", hostInfoString, hostConfigMap.size()));

		if ((hostConfig.getRemotePort() <= 0) || (hostConfig.getRemotePort() > 65535))
		{
			LOGGER.warning(String.format("Invalid hostInfoString (%s) passed to ConnectionConfig::getHostConfig", hostInfoString));
		}
	}

	public boolean removeHost(String hostInfoString)
	{
		HostConfig removedHostConfig = hostConfigMap.remove(hostInfoString);

		if (removedHostConfig == null)
		{
			LOGGER.info("Did not find any hostconfig entry mapped to " + hostInfoString);
			return false;
		}
		else
		{
			LOGGER.info("Sucessfully removed hostconfig mapped to " + hostInfoString);
			return true;
		}
	}

	public void addNATPair(String ipCsp, String ipClient)
	{
		// trim whitespace from start/end of input strings
		ipCsp = ipCsp.trim();
		ipClient = ipClient.trim();

		String ipClientMapped = natMap1.get(ipCsp);

		if (ipClientMapped != null)
		{
			LOGGER.warning(String.format("Failed to add NAT pair %s, %s: CSP ip %s already exists in a NAT pair", ipCsp, ipClient, ipCsp));
			return;
		}

		natMap1.put(ipCsp, ipClient);

		String ipCspMapped = natMap2.get(ipClient);
		if (ipCspMapped != null)
		{
			LOGGER.warning(String.format("Failed to add NAT pair %s, %s: local ip %s already exists in a NAT pair", ipCsp, ipClient, ipClient));
			//// we know it is there, we just inserted, remove from the other map as well
			ipClientMapped = natMap1.remove(ipCsp);

			if (natMap2 == null)
				LOGGER.warning(String.format("Failed to find NAT entry for CSP ip %s", ipCsp)); // should never happen

			return;
		}

		natMap2.put(ipClient, ipCsp);

		LOGGER.info(String.format("Adding NAT pair %s, %s", ipCsp, ipClient));
	}

	/**
	 * Given a remote CSP IP address return the local NAT IP address
	 * @param ipCsp
	 * @return
	 */
	public String getLocalIp(String ipCsp)
	{
		String ipClient = null;
		if (ipCsp != null) {
			ipClient = natMap1.get(ipCsp);
			if (ipClient == null) {
				LOGGER.info(String.format("No Local NAT address found for %s", ipCsp));
			}
		}
		return ipClient;
	}

	/**
	 *
	 * Given a local IP address return the remote CSP IP address
	 * @param ipLocal
	 * @return
	 */
	public String getCsplIp(String ipLocal)
	{
		String ipCsp = null;
		if (ipLocal != null) {
			ipCsp = natMap2.get(ipLocal);
			if (ipCsp == null) {
				LOGGER.info(String.format("No CSP NAT address found for %s", ipLocal));
			}
		}
		return ipCsp;
	}

	public void set(Parameters parameter, boolean paramVal)
	{
		switch (parameter)
		{
		case COMPRESSION_BOOL:
			this.compression = paramVal;
			LOGGER.info(String.format("COMPRESSION_BOOL=%s", paramVal));
			break;
		case CONFLATION_INDICATOR_BOOL:
			conflationIndicator = paramVal;
			LOGGER.info(String.format("CONFLATION_INDICATOR_BOOL=%s", paramVal));
			break;
		default:
			LOGGER.warning(String.format("Invalid parameter (%s) passed to ConnectionConfig::set(bool)", paramVal));
		}
	}

	public void set(Parameters parameter, long paramVal)
	{
		switch (parameter)
		{
			case CONFLATION_INTERVAL_LONG:
				conflationInterval = (int) paramVal;
				LOGGER.info(String.format("CONFLATION_INTERVAL_LONG=%d", paramVal));
				break;
			case CONFLATION_TYPE_LONG:
				conflationType = (int) paramVal;
				if (!ConflationType.isConflationTypeValid((int)paramVal)) {
					conflationType = 1;
					LOGGER.info(String.format("CONFLATION_TYPE_LONG set to invalid value of %d; will set to default of 1", paramVal));
				}
				LOGGER.info(String.format("CONFLATION_TYPE_LONG=%d", conflationType));
				break;
			case READ_TIMEOUT_LONG:
				readTimeout = paramVal;
				LOGGER.info(String.format("READ_TIMEOUT_LONG=%d", paramVal));
				break;
			case CONNECTION_TIMEOUT_LONG:
				connectionTimeout = paramVal;
				LOGGER.info(String.format("CONNECTION_TIMEOUT_LONG=%d", paramVal));
				break;
			case CONNECTION_RETRY_LIMIT_LONG:
				connectionRetryLimit = paramVal;
				LOGGER.info(String.format("CONNECTION_RETRY_LIMIT_LONG=%d", paramVal));
				break;
			case QUEUE_SIZE_LONG:
				queueSize = paramVal;
				if (paramVal <= 0) {
					queueSize = 1;
					LOGGER.info(String.format("QUEUE_SIZE_LONG set to invalid value of %d; will set to default of 1", paramVal));
				} else if (paramVal > 256) {
					LOGGER.info(String.format("QUEUE_SIZE_LONG set to invalid value of %d; will set to default of 256", paramVal));
					queueSize = 256;
				}
				LOGGER.info(String.format("QUEUE_SIZE_LONG=%d", queueSize));
				break;
			case JIT_CONFLATION_THRESHOLD_PERCENT_LONG:
				jitThreshold = (int) paramVal;
				if (jitThreshold < MIN_JIT_THRESHOLD) {
					LOGGER.warning(String.format("Requested JIT_CONFLATION_THRESHOLD_PERCENT_LONG of %d percent is smaller than the minimum of %d; will use %d percent", jitThreshold, MIN_JIT_THRESHOLD, MIN_JIT_THRESHOLD));
					jitThreshold = MIN_JIT_THRESHOLD;
				} else if (jitThreshold > MAX_JIT_THRESHOLD) {
					LOGGER.warning(String.format("Requested JIT_CONFLATION_THRESHOLD_PERCENT_LONG of %d percent is larger than the maximum of %d; will use %d percent", jitThreshold, MAX_JIT_THRESHOLD, MAX_JIT_THRESHOLD));
					jitThreshold = MAX_JIT_THRESHOLD;
				}
				LOGGER.info(String.format("JIT_CONFLATION_THRESHOLD_PERCENT_LONG=%d", jitThreshold));
				break;
			default:
				LOGGER.warning(String.format("Invalid parameter (%d) passed to ConnectionConfig::set(long)", paramVal));
		}
	}

	public long getLong(Parameters parameter, long defaultVal)
	{
		switch (parameter)
		{
			case CONFLATION_INTERVAL_LONG:
				return conflationInterval;
			case CONFLATION_TYPE_LONG:
				return conflationType;
			case READ_TIMEOUT_LONG:
				return readTimeout;
			case CONNECTION_TIMEOUT_LONG:
				return connectionTimeout;
			case CONNECTION_RETRY_LIMIT_LONG:
				return connectionRetryLimit;
			case QUEUE_SIZE_LONG:
				return queueSize;
			case JIT_CONFLATION_THRESHOLD_PERCENT_LONG:
				return jitThreshold;
		default:
			LOGGER.warning(String.format("Invalid parameter (%s) passed to ConnectionConfig::getLong", parameter.toString()));
		}

		return defaultVal;
	}

	public boolean getBoolean(Parameters parameter, boolean defaultVal)
	{
		switch (parameter)
		{
		case COMPRESSION_BOOL:
			return compression;
		case CONFLATION_INDICATOR_BOOL:
			return conflationIndicator;
		default:
			LOGGER.warning(String.format("Invalid parameter (%s) passed to ConnectionConfig::getBoolean", parameter.toString()));
		}

		return defaultVal;
	}

	public boolean isCompression()
	{
		return compression;
	}

	public void setCompression(boolean compression)
	{
		this.compression = compression;
	}

	public boolean isConflationIndicator()
	{
		return conflationIndicator;
	}

	public void setConflationIndicator(boolean conflationIndicator)
	{
		this.conflationIndicator = conflationIndicator;
	}

	public long getConflationInterval()
	{
		return conflationInterval;
	}

	public void setConflationInterval(int conflationInterval)
	{
		this.conflationInterval = conflationInterval;
	}

	public long getConnectionRetryLimit()
	{
		return connectionRetryLimit;
	}

	public void setConnectionRetryLimit(long connectionRetryLimit)
	{
		this.connectionRetryLimit = connectionRetryLimit;
	}

	public long getConnectionTimeout() {
		return connectionTimeout;
	}

	public long getQueueSize()
	{
		return queueSize;
	}

	public void setQueueSize(long queueSize)
	{
		this.queueSize = queueSize;
	}

	public void setConnectionTimeout(long connectionTimeout)
	{
		this.connectionTimeout = connectionTimeout;
	}

	public int getHostConfigsSize(boolean isPrimary)
	{
		if (isPrimary)
		{
			return primaryHostConfigs.size();
		}
		else
		{
			return backupHostConfigs.size();
		}
	}

	public HostConfig getBackupHostConfig(int index)
	{
		if (index >= 0 && index < backupHostConfigs.size())
		{
			return backupHostConfigs.get(index);
		}
		return null;
	}

	public HostConfig getPrimaryHostConfig(int index)
	{
		if (index >= 0 && index < primaryHostConfigs.size())
		{
			return primaryHostConfigs.get(index);
		}
		return null;
	}

	public Set<Integer> getCspTypePorts(boolean usePrimary)
	{
		if (usePrimary)
		{
			return primaryPorts;
		}
		else
		{
			return backupPorts;
		}
	}

	public Set<String> getCMIps()
	{
		return m_CMList;
	}

	public boolean checkIPsAreSame(boolean useBackupIps)
	{
		List<HostConfig> hostConfigs = null;
		if (useBackupIps)
		{
			hostConfigs = backupHostConfigs;
		}
		else
		{
			hostConfigs = primaryHostConfigs;
		}
		
		String cmIP = null;
		synchronized (hostConfigs)
		{
			for (HostConfig backupHostConfig : hostConfigs)
			{
				if (cmIP == null)
				{
					cmIP = backupHostConfig.getOrigRemoteHostIp();
				}
				else if (!cmIP.equals(backupHostConfig.getOrigRemoteHostIp()))
				{
					if (useBackupIps)
					{
						LOGGER.warning(String.format("checkIPsAreSame error - Backup CM IPs are not the same CMIPS=[%s, %s]", cmIP,
								backupHostConfig.getOrigRemoteHostIp()));
					}
					else
					{
						LOGGER.warning(String.format("checkIPsAreSame error - Primary CM IPs are not the same CMIPS=[%s, %s]", cmIP,
								backupHostConfig.getOrigRemoteHostIp()));
					}
					return false;
				}
			}
		}
		return true;
	}


	public List<HostConfig> getPrimaryHostConfigs() {
		return primaryHostConfigs;
	}

	public List<HostConfig> getBackupHostConfigs() {
		return backupHostConfigs;
	}
	public void clearHostConfigsMap() {
		LOGGER.info("Clearing off " + hostConfigMap.size() + " hostConfig entries from hostConfigMap.");
		hostConfigMap.clear();
	}

	public Set<Integer> getPrimaryPorts() {
		return primaryPorts;
	}

	public Set<Integer> getBackupPorts() {
		return backupPorts;
	}

	public Map<String, HostConfig> getHostConfigMap() {
		return hostConfigMap;
	}
}
