package com.theice.cfapi.session;

import java.util.logging.Logger;

public class SessionConfig
{
	public static final long MAX_REQUEST_Q_SIZE_MAX = 50000000;

	public enum Parameters
	{
		/**
		 * Enables or disables connection and content recovery true = enables (default); false = disables;
		 */
		@Deprecated
		RECOVERY_BOOL,

		/**
		 * Indicate whether API should create one thread per backend CSP connection. Default is false (one thread for all
		 * connections)
		 */
		MULTITHREADED_API_CONNECTIONS_BOOL,

		/**
		 * When MULTITHREADED_API_CONNECTIONS_BOOL=true, this indicates the maximum number of user-side threads the API should
		 * create. If set to 0 (default), <0, or not set, the API will open as many threads as it can use.
		 */
		MAX_USER_THREADS_LONG,

		/**
		 * When MULTITHREADED_API_CONNECTIONS_BOOL=true, this indicates the maximum number of CSP-side (backend) threads the API
		 * should create. If set to 0 (default), <0, or not set, the API will open as many threads as it can use.
		 */
		MAX_CSP_THREADS_LONG,

		/**
		 *
		 * Maximum number of requests to be queued before sending to the CSP.  Default is 100000 (without watchlist) or 10000000 (with watchlist);
		 * valid range is 100000-50000000 (requests)
		 *
		 */
		MAX_REQUEST_QUEUE_SIZE_LONG,

		/**
		 * Indicate whether API should use watchlist to manage requests.  Default is false.
		 */
		WATCHLIST_BOOL,

		/**
		 * Maximum number of requests to be added to watchlist.  Default is 10000000 (requests)
		 */
		MAX_WATCHLIST_SIZE_LONG,

		/**
		 * Threshold to trigger CFAPI_SESSION_RECEIVE_QUEUE_ABOVE_THRESHOLD and CFAPI_SESSION_RECEIVE_QUEUE_BELOW_THRESHOLD SessionEvents.  Default is 70%; valid range is 1-101
		 */
		QUEUE_DEPTH_THRESHOLD_PERCENT_LONG;
	}

	private static final Logger LOGGER = Logger.getLogger(SessionConfig.class.getName());
	private boolean multithreaded;
	private long maxUserThreads = 1;
	private long maxCspThreads = 1;
	private long maxRequestQueueSize;

	private boolean watchlist = false;
	private long maxWatchlistSize = 10000000;
	private int queueDepthThreshold = 70;
	private boolean maxReqQSizeSet = false;

	/**
	 * Sets session parameters. If not previously set, this will create and set value. If already set, this will replace setting
	 *
	 * @param parameter
	 *            A SessionConfig.Parameter value that corresponds to the config value
	 * @param value
	 *            The value of the desired parameter
	 */
	public void set(Parameters parameter, String value)
	{
		LOGGER.info(String.format("Setting Parameter=%s, with value=%s", parameter.name(), value));
		switch (parameter)
		{
		case RECOVERY_BOOL:
		case MULTITHREADED_API_CONNECTIONS_BOOL:
		case WATCHLIST_BOOL :
			set(parameter, Boolean.valueOf(value));
			break;
		case MAX_USER_THREADS_LONG:
		case MAX_CSP_THREADS_LONG:
		case MAX_REQUEST_QUEUE_SIZE_LONG:
		case MAX_WATCHLIST_SIZE_LONG:
		case QUEUE_DEPTH_THRESHOLD_PERCENT_LONG:
			set(parameter, Long.valueOf(value));
			break;
		default:
			break;
		}
	}

	void set(Parameters parameter, boolean value)
	{
		switch (parameter)
		{
		case RECOVERY_BOOL:
			LOGGER.warning("RECOVERY_BOOL is deprecated, value will be ignored");
			break;
		case MULTITHREADED_API_CONNECTIONS_BOOL:
			multithreaded = value;
			LOGGER.info(String.format("MULTITHREADED_API_CONNECTIONS_BOOL=%s", (value ? "true" : "false")));
			break;
		case WATCHLIST_BOOL :
			watchlist = value;
			LOGGER.info(String.format("WATCHLIST_BOOL=%s", (value ? "true" : "false")));
			if (watchlist && !maxReqQSizeSet)
				maxRequestQueueSize = 10000000;	//higher default when using watchlist
			break;
		default:
			LOGGER.warning(String.format("Invalid parameter (%s) passed to SessionConfigImpl::set(bool)", parameter));
			break;
		}
	}

	void set(Parameters parameter, long value) {
		switch (parameter) {
			case MAX_USER_THREADS_LONG:
				maxUserThreads = value;
				if (maxUserThreads <= 0) {
					maxUserThreads = 1;
					LOGGER.warning(String.format("MAX_USER_THREADS_LONG set to invalid value of %d; will set to default of 1", value));
				}
				LOGGER.info(String.format("MAX_USER_THREADS_LONG=%d", maxUserThreads));
				break;
			case MAX_CSP_THREADS_LONG:
				maxCspThreads = value;
				if (maxCspThreads <= 0) {
					maxCspThreads = 1;
					LOGGER.warning(String.format("MAX_CSP_THREADS_LONG set to invalid value of %d; will set to default of 1", value));
				}
				LOGGER.info(String.format("MAX_CSP_THREADS_LONG=%d", maxCspThreads));
				break;
			case MAX_REQUEST_QUEUE_SIZE_LONG:
				maxRequestQueueSize = value;
				if (maxRequestQueueSize < 100000) {
					LOGGER.info(String.format("MAX_REQUEST_QUEUE_SIZE_LONG set to invalid value of %d; will set to default of 100000", value));
					maxRequestQueueSize = 100000;
				} else if (maxRequestQueueSize > MAX_REQUEST_Q_SIZE_MAX) {
					maxRequestQueueSize = MAX_REQUEST_Q_SIZE_MAX;
					LOGGER.warning(String.format("MAX_REQUEST_QUEUE_SIZE_LONG set to invalid value of %d; will set to maximum of %d", value, MAX_REQUEST_Q_SIZE_MAX));
				}
				LOGGER.info(String.format("MAX_REQUEST_QUEUE_SIZE_LONG=%d", maxRequestQueueSize));
				maxReqQSizeSet = true;
				break;
			case MAX_WATCHLIST_SIZE_LONG:
				maxWatchlistSize = value;
				if (maxWatchlistSize < 1) {
					maxWatchlistSize = 1;
					LOGGER.warning(String.format("MAX_WATCHLIST_SIZE_LONG set to invalid value of %d; will set to minimum of 1", value));
				}
				LOGGER.info(String.format("MAX_WATCHLIST_SIZE_LONG=%d", maxWatchlistSize));
				break;
			case QUEUE_DEPTH_THRESHOLD_PERCENT_LONG:
				queueDepthThreshold = (int)value;
				if (queueDepthThreshold < 1) {
					queueDepthThreshold = 1;
					LOGGER.warning(String.format("QUEUE_DEPTH_THRESHOLD_PERCENT_LONG set to invalid value of %d; will set to minimum of 1", value));
				}
				else if (queueDepthThreshold > 101) {
					queueDepthThreshold = 101;
					LOGGER.warning(String.format("QUEUE_DEPTH_THRESHOLD_PERCENT_LONG set to invalid value of %d; will set to maximum of 101", value));
				}
				LOGGER.info(String.format("QUEUE_DEPTH_THRESHOLD_PERCENT_LONG=%d", queueDepthThreshold));
				break;
			default:
				LOGGER.warning(String.format("Invalid parameter (%d) passed to SessionConfigImpl::set(long)", parameter));
				break;
		}
	}

	public boolean isMultithreaded()
	{
		return multithreaded;
	}

	public long getMaxUserThreads()
	{
		return maxUserThreads;
	}

	public long getMaxCspThreads()
	{
		return maxCspThreads;
	}

	public long getMaxRequestQueueSize()
	{
		return maxRequestQueueSize;
	}

	public boolean isWatchlist() {
		return watchlist;
	}

	public long getMaxWatchlistSize() {
		return maxWatchlistSize;
	}

	public void setMaxRequestQueueSize(long maxRequestQueueSize) {
		this.maxRequestQueueSize = maxRequestQueueSize;
	}

	public int getQueueDepthThreshold() {
		return queueDepthThreshold;
	}
}
