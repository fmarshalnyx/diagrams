package com.theice.cfapi.event;

import java.util.List;

import com.theice.cfapi.data.MessageField;
import com.theice.cfapi.data.MessageReader;
import com.theice.cfapi.session.Session;

public interface MessageEvent
{

	public enum Types
	{
		/**
		 * Partial image received, rest will follow (e.g. snapshot message for one instrument in a multi-instrument snapshot request
		 * that is not the last)
		 */
		IMAGE_PART,

		/**
		 * Image is complete (e.g. the last (or only) message of a snapshot)
		 */
		IMAGE_COMPLETE,

		/**
		 * This event contains an update event. (e.g. one message in a subscribe response)
		 */
		UPDATE,

		/**
		 * Refresh (e.g. refresh message in subscribe response)
		 */
		REFRESH,

		/**
		 * Event contains status information from the CSP
		 */
		STATUS
	};

	/**
	 * Returns the session associated with this event
	 *
	 * @return Session that this event came from
	 */
	public Session getSession();

	/**
	 * Returns the symbol for this message
	 *
	 * @return The symbol for this message
	 */
	public String getSymbol();

	/**
	 * Returns the permission for this message
	 *
	 * @return The permission for this message
	 */
	public int getPermission();

	/**
	 * Returns the source for this message
	 *
	 * @return The source for this message
	 */
	public int getSource();

	public long getTag();

	public int getStatusCode();

	public String getStatusCodeString();

	/**
	 * Is this message conflatable
	 *
	 * @return -1 (unknown) if CONFLATION_INDICATOR_BOOL is false 0 (false) if not conflatable 1 (true) if conflatable
	 */
	public int isConflatable();

	public int getAlternateIndexTokenNumber(int altidPos);

	public String getAlternateIndexTokenName(int altidPos);

	public String getAlternateIndexValue(int altidPos);

	public int getNumberofAlternateIndexes();

	/**
	 * gets the first message field in the content that matches the ctf token id
	 * 
	 * @param ctfTokenId
	 * @return
	 */
	@Deprecated
	public MessageField getFirst(int ctfTokenId);

	/**
	 * Returns all the fields contained in this event encapsulated
	 *
	 * @return MessageReader that can be used to process this content
	 */
	@Deprecated
	public List<MessageField> getMessageFields();

	public Types getType();

	public MessageReader getReader();

}
