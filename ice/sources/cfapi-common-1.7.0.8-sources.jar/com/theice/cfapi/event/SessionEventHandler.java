package com.theice.cfapi.event;

/**
 * User: dkim
 * Date: 3/8/2017
 * Time: 2:52 PM
 */
public interface SessionEventHandler {
   void onSessionEvent( SessionEvent sessionEvent);
}
