package com.theice.cfapi.event;


public interface UserEventHandler {

   void onUserEvent( UserEvent event );

}
