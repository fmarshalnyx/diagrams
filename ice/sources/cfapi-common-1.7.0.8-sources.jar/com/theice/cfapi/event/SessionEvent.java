package com.theice.cfapi.event;

import com.theice.cfapi.session.Session;

public interface SessionEvent
{
	public enum Types
	{
		/**
		 * No connections established to any backend CSPs
		 */
		CFAPI_SESSION_UNAVAILABLE(0),
		/**
		 * Connections established to all backend CSPs
		 */
		CFAPI_SESSION_ESTABLISHED(1),
		/**
		 * Connection established to at least one CSP; trying to recover at least one CSP connection.
		 */
		CFAPI_SESSION_RECOVERY(2),
		/**
		 * CDD downloaded from CSP; expect at session start and during session when new CDD detected.
		 */
		CFAPI_CDD_LOADED(3),
		/**
		 * Connections established to all backend CSPs and send all sources available
		 */
		CFAPI_SESSION_AVAILABLE_ALLSOURCES(4),
		/**
		 * CSP health status; Connection to CSP(s) was restored and send the sources that became available
		 */
		CFAPI_SESSION_AVAILABLE_SOURCES(5),
		/**
		 * CSP health status; Connection to one or more CSPs was lost and send the sources that are unavailable
		 */
		CFAPI_SESSION_RECOVERY_SOURCES(6),

		/**
		 * Receive queue percentage full has exceeded the threshold
		 */
		CFAPI_SESSION_RECEIVE_QUEUE_ABOVE_THRESHOLD(7),

		/**
		 * Receive queue percentage full has dropped below the threshold
		 */
		CFAPI_SESSION_RECEIVE_QUEUE_BELOW_THRESHOLD(8),

		/**
		 * One or more backend CSPs have started conflating all streaming data
		 */
		CFAPI_SESSION_JIT_START_CONFLATING(9),

		/**
		 * All backend CSPs have stopped conflating
		 */
		CFAPI_SESSION_JIT_STOP_CONFLATING(10),

		/**
		 * New source has been added
		 */
		CFAPI_SESSION_SOURCE_ADDED(11),

		/**
		 * Source has been removed
		 */
		CFAPI_SESSION_SOURCE_REMOVED(12);

		int value;

		Types(int value)
		{
			this.value = value;
		}

		public int getValue()
		{
			return value;
		}
	};

	/**
	 * Returns information about the specific type of event that occurred.
	 * 
	 * @return SessionEvent.Types
	 */
	public Types getType();

	/**
	 * Returns the session that this event describes
	 */
	public Session getSession();

	/**
	 * Returns the current CDD version when event type is CFAPI_CDD_LOADED
	 */
	public String getCddVersion();

	/**
	 * Returns the source ID when session event types becomes CFAPI_SESSION_AVAILABLE_ALLSOURCES / CFAPI_SESSION_AVAILABLE_SOURCES /
	 * CFAPI_SESSION_RECOVERY_SOURCES
	 */
	public int getSourceId();

	/**
	 * Returns the queue depth percent when session event type is CFAPI_SESSION_RECEIVE_QUEUE_ABOVE_THRESHOLD /
	 * CFAPI_SESSION_RECEIVE_QUEUE_BELOW_THRESHOLD
	 */
	public int getQueueDepth();

}
