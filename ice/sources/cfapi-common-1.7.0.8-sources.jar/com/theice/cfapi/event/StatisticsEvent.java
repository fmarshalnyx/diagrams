package com.theice.cfapi.event;

import com.theice.cfapi.session.Session;

public interface StatisticsEvent
{
	/**
	 * enumeration of statistics that can be requested
	 */
	public enum StatsTypes
	{
		/**
		 * Total messages received by the API from the backend CSP(s).
		 */
		MSGS_IN(0),

		/**
		 * Total messages processed by the API. This includes internal messages not sent to the user application; see NET_MSGS_OUT.
		 */
		MSGS_OUT(1),

		/**
		 * Total bytes dropped by the API
		 */
		DROP(2),

		/**
		 * Total bytes dropped by the CSP prior to being sent to the API
		 */
		CSP_DROP(3),

		/**
		 * Current depth of internal API message-data queue
		 */
		PCT_FULL(4),

		/**
		 * Max depth of internal API message-data queue since last StatisticsEvent
		 */
		PEAK_PCT_FULL(5),

		/**
		 * Current burst input rate of message-data from the CSP in msgs/sec, using a 100ms sample rate
		 */
		IN_MSGS_SEC_100MS(6),

		/**
		 * Max burst input rate of message-data from the CSP in msgs/sec, using a 100ms sample rate, since the last StatisticsEvent
		 */
		PEAK_IN_MSGS_SEC_100MS(7),

		/**
		 * Current input rate of message-data from the CSP in msgs/sec
		 */
		IN_MSGS_SEC(8),

		/**
		 * Max input rate of message-data from the CSP in msgs/sec since the last StatisticsEvent
		 */
		PEAK_IN_MSGS_SEC(9),

		/**
		 * Current burst output rate of message-data read from the API in msgs/sec, using a 100ms sample rate
		 */
		OUT_MSGS_SEC_100MS(10),

		/**
		 * Max burst output rate of message-data read from the API in msgs/sec, using a 100ms sample rate, since the last
		 * StatisticsEvent
		 */
		PEAK_OUT_MSGS_SEC_100MS(11),

		/**
		 * Current output rate of message-data read from the API in msgs/sec
		 */
		OUT_MSGS_SEC(12),

		/**
		 * Max output rate of message-data read from the API in msgs/sec since the last StatisticsEvent
		 */
		PEAK_OUT_MSGS_SEC(13),

		/**
		 * Total messages passed from the API to the user application via the onMessageEvent() callback This can differ from
		 * MSGS_IN/MSGS_OUT, which includes internal messages filtered out by the API.
		 */
		NET_MSGS_OUT(14),

		/**
		 * Current burst output rate of message-data sent to the user application via the onMessageEvent() callback in msgs/sec,
		 * using a 100ms sample rate
		 */
		NET_OUT_MSGS_SEC_100MS(15),

		/**
		 * Max burst output rate of message-data sent to the user application via the onMessageEvent() callback in msgs/sec, using a
		 * 100ms sample rate, since the last StatisticsEvent
		 */
		PEAK_NET_OUT_MSGS_SEC_100MS(16),

		/**
		 * Current output rate of message-data sent to the user application via the onMessageEvent() callback in msgs/sec
		 */
		NET_OUT_MSGS_SEC(17),

		/**
		 * Max output rate of message-data sent to the user application via the onMessageEvent() callback in msgs/sec since the last
		 * StatisticsEvent
		 */
		PEAK_NET_OUT_MSGS_SEC(18);

		int value;

		public int getValue()
		{
			return value;
		}

		private StatsTypes(int value)
		{
			this.value = value;
		}
	};

	public Session getSession();

	public long getStat(StatsTypes type);

}
