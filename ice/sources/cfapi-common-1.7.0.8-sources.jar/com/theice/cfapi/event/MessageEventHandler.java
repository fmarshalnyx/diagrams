package com.theice.cfapi.event;

public interface MessageEventHandler
{
	void onMessageEvent(MessageEvent event);
}
