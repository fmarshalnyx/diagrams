package com.theice.cfapi.event;

public interface StatisticsEventHandler
{
	/**
	 * 
	 * @param event
	 *            carries the fired statistics event<br>
	 *            Note this event is not preserved after return from this function.
	 */
	void onStatisticsEvent(StatisticsEvent statisticsEvent);

}
