package com.theice.cfapi.event;

import com.theice.cfapi.session.Session;
import com.theice.cfapi.user.UserInfo;

public interface UserEvent
{

	public enum Types
	{
		AUTHORIZATION_FAILURE((short) 0), AUTHORIZATION_SUCCESS((short) 1);
		short value;

		private Types(short value)
		{
			this.value = value;
		}

		public short getValue()
		{
			return value;
		}
	}

	public Types getType();

	public Session getSession();

	public UserInfo getUserInfo();

	public int getRetCode();

	public String getRetCodeString();

}
